// @flow
import React from 'react';
import DefaultLayout from 'containers/Layout/DefaultLayout';
import { Container, Grid, Button, Text, Image, View, Dropdown } from 'components';
import { Intl } from 'intlized-components';
import styles from './Styles';
import ThreeBox from './ThreeBox';
// import LiveSearch from '../../../app/containers/Layout/DefaultLayout/LiveSearch';

function Home() {
  return (
    <DefaultLayout>
      <View style={{ backgroundColor: '#f6fafd' }}>
        <View style={{ minHeight: 350 }}>
          <Image source="/img/home/bg-splash.png" style={{ width: '100%' }} label="Examunity" />
          <View style={styles.searchView}>
            <Text h1="true" style={styles.searchViewTitle}>
              Finde deine Lerngruppen
            </Text>
            <View style={styles.searchViewBar}>
              <Grid>
                <Grid.Box size={12} sizeMd={10}>
                  <Dropdown style={styles.searchViewBoxSelect}>
                    <Button
                      color="secondary"
                      class="f-row ai-center"
                      style={{ width: '100%', height: '100%' }}
                    >
                      <Text>University Groups</Text>
                    </Button>
                    <Dropdown.Menu style={{ width: '100%' }}>
                      <Dropdown.Header>
                        <Text>Header</Text>
                      </Dropdown.Header>
                      <Dropdown.Item onClick={() => {}}>
                        <Text>Test 1</Text>
                      </Dropdown.Item>
                      <Dropdown.Divider />
                      <Dropdown.TextItem>
                        <Text>Test 2</Text>
                      </Dropdown.TextItem>
                    </Dropdown.Menu>
                  </Dropdown>
                </Grid.Box>
                <Grid.Box size={12} sizeMd={2}>
                  <View
                    style={{
                      height: 60,
                      width: 60,
                      borderRadius: 5,
                      borderWidth: 1,
                      borderColor: '#e0e0e0',
                      backgroundColor: '#fff',
                      cursor: 'pointer',
                      padding: 2,
                    }}
                  >
                    <Image
                      source="/img/icon-search.png"
                      label="Search"
                      style={{
                        height: '100%',
                        width: '100%',
                        backgroundColor: '#e86551',
                        borderWidth: 1,
                        borderColor: '#fff',
                        borderRadius: 5,
                        cursor: 'pointer',
                        padding: 7,
                      }}
                    />
                  </View>
                </Grid.Box>
              </Grid>
            </View>
          </View>
        </View>

        <Intl>
          {intl => (
            <View>
              <View style={{ marginTop: -60, zIndex: 99 }}>
                <View
                  style={{
                    position: 'absolute',
                    top: 20,
                    left: 0,
                    width: '100%',
                    height: '100%',
                  }}
                >
                  <Image source="/img/home/bg-target.png" label="background" />
                </View>
                <Container>
                  <View>
                    <Grid>
                      <Grid.Box size={12} sizeMd={4}>
                        {intl.locale === 'en' && (
                          <ThreeBox
                            logo="/img/logos/mortarboard-128.png"
                            buttonText="UNIVERSITY"
                            bgColor="blue"
                            text1="Find online study groups at your university or easily add new ones and invite your classmates"
                            text2="Help yourself using memory minutes and reviews from former students and add your own experiences"
                            bottomButtonText="TO CAMPUS"
                            last="no"
                          />
                        )}
                        {intl.locale === 'de' && (
                          <ThreeBox
                            logo="/img/logos/mortarboard-128.png"
                            buttonText="STUDIUM"
                            bgColor="blue"
                            text1="Finde Lerngruppen an deiner Uni oder erstelle mit wenigen Klicks deine eigene und lade deine Kommilitonen ein"
                            text2="Nutze das Wissen deiner Vorgänger, indem du Gedächtnisprotokolle und Reviews abrufst und deine eigenen Erfahrungen teilst"
                            bottomButtonText="ZUM CAMPUS"
                            last="no"
                          />
                        )}
                      </Grid.Box>

                      <Grid.Box size={12} sizeMd={4}>
                        {intl.locale === 'en' && (
                          <ThreeBox
                            logo="/img/logos/certificate-128.png"
                            buttonText="APPRENTICESHIP"
                            bgColor="orange"
                            text1="Collaborate in study groups with other apprentices from your school, your company or nationwide"
                            text2="Study with 4.800+ free exercises or add and share your own"
                            bottomButtonText="ZUM EMPFANG"
                            last="no"
                          />
                        )}
                        {intl.locale === 'de' && (
                          <ThreeBox
                            logo="/img/logos/certificate-128.png"
                            buttonText="AUSBILDUNG"
                            bgColor="orange"
                            text1="Schließe dich in Lerngruppen mit Azubis aus deiner Berufsschule, deinem Betrieb oder aus ganz Deutschland zusammen"
                            text2="Lerne mit über 4.800 Übungsaufgaben oder erstelle und teile deine eigenen Lernmaterialien"
                            bottomButtonText="ZUM EMPFANG"
                            last="no"
                          />
                        )}
                      </Grid.Box>

                      <Grid.Box size={12} sizeMd={4}>
                        {intl.locale === 'en' && (
                          <ThreeBox
                            logo="/img/logos/school-128.png"
                            buttonText="SCHOOL"
                            bgColor="blue"
                            text1="Prepare together with your classmates on your upcoming exams"
                            text2="Find students from other schools, collaborate and prepare on the final exams together using thousands of free materials"
                            bottomButtonText="TO SCHOOL HALL"
                            last="yes"
                          />
                        )}
                        {intl.locale === 'de' && (
                          <ThreeBox
                            logo="/img/logos/school-128.png"
                            buttonText="SCHULE"
                            bgColor="blue"
                            text1="Bereite dich zusammen mit deinen Klassenkameraden auf die nächste Klausur vor"
                            text2="Lerne deutschlandweit mit anderen Schülern für die zentralen Prüfungen und teile deine Erfahrungen"
                            bottomButtonText="ZUR AULA"
                            last="yes"
                          />
                        )}
                        {/* {
                          boxShadow: '0px 0px 22px -3px rgba(0, 0, 0, 0.75)',
                          marginTop: 10,
                        }, */}                  
                      </Grid.Box>
                    </Grid>
                  </View>

                  <View>
                    <View>
                      <Text
                        style={{
                          color: '#0084a6',
                          fontSize: 45,
                          textAlign: 'center',
                          fontWeight: 'bold',
                          marginBottom: 50,
                          paddingTop: 20,
                        }}
                      >
                        Was ist Examunity?
                      </Text>
                    </View>
                    <Grid>
                      <Grid.Box size={12} sizeMd={5}>
                        <View style={{ paddingTop: '50', paddingLeft: 50, height: '100%' }}>
                          <Text
                            style={{
                              fontSize: 30,
                              fontWeight: 'bold',
                              paddingTop: 70,
                            }}
                          >
                            Finde Lerngruppen oder erstelle einfache deine eigenen und lerne
                            zusammen mit deinen Kollegen
                          </Text>
                        </View>
                      </Grid.Box>
                      <Grid.Box size={12} sizeMd={7}>
                        <Image
                          source="/img/home/img-feat1.png"
                          label="Feat-1"
                          style={{ maxWidth: '90%' }}
                        />
                      </Grid.Box>
                    </Grid>

                    <Grid style={{ marginTop: 50 }}>
                      <Grid.Box size={12} sizeMd={7}>
                        <Image
                          source="/img/home/img-feat2.png"
                          label="Feat-1"
                          style={{ maxWidth: '90%' }}
                        />
                      </Grid.Box>
                      <Grid.Box size={12} sizeMd={5}>
                        <View style={{ paddingTop: '50', paddingLeft: 50, height: '100%' }}>
                          <Text
                            style={{
                              fontSize: 30,
                              fontWeight: 'bold',
                              paddingTop: 70,
                            }}
                          >
                            Bereite dich zusammen mit deinen Klassenkameraden auf die nächste
                            Klausur vor
                          </Text>
                        </View>
                      </Grid.Box>
                    </Grid>

                    <Grid style={{ marginTop: 50 }}>
                      <Grid.Box size={12} sizeMd={5}>
                        <View style={{ paddingTop: '50', paddingLeft: 50, height: '100%' }}>
                          <Text
                            style={{
                              fontSize: 30,
                              fontWeight: 'bold',
                              paddingTop: 70,
                            }}
                          >
                            Lerne mit tausenden Aufgaben, teile dein Wissen und nutze das Wissen
                            deiner Vorgänger
                          </Text>
                        </View>
                      </Grid.Box>
                      <Grid.Box size={12} sizeMd={7}>
                        <Image
                          source="/img/home/img-feat3.png"
                          label="Feat-1"
                          style={{ maxWidth: '90%' }}
                        />
                      </Grid.Box>
                    </Grid>
                  </View>
                </Container>
              </View>

              <View>
                <Container>
                  <View>
                    <Grid>
                      <Grid.Box size={12} sizeMd={6}>
                        <View
                          style={{
                            width: '98%',
                            boxShadow: '0px 0px 22px -3px rgba(0, 0, 0, 0.75)',
                            backgroundColor: '#fff',
                            borderRadius: 2,
                            padding: 40,
                            marginTop: 40,
                          }}
                        >
                          <Text
                            h4="true"
                            style={{ color: '#e86551', fontWeight: 'bold', fontSize: 20 }}
                          >
                            FUR
                          </Text>
                          <Text
                            h2="true"
                            style={{ color: '#0084a6', fontWeight: 'bold', fontSize: 20 }}
                          >
                            Unternehmen
                          </Text>
                          <ul
                            style={{
                              marginBottom: 40,
                              marginTop: 25,
                            }}
                          >
                            <li>
                              <Text>
                                Bieten Sie Ihren Auszubildenden eine vollig neue Form des
                                gemeinsamen Lernens. Nutzen Sie Tausende von Ubungsaufgaben oder
                                erstellen Sie eigene Inhalte
                              </Text>
                            </li>
                            <li>
                              <Text>
                                Bewahren Sie wertvolles Wissen in lhrem Betrieb-mit
                                Erfahrungsberichten und Gedachtnisprotokollen zu Klaunsuren,
                                Seminaren und vielem mehr erstellen lhre
                              </Text>
                            </li>
                            <li>
                              <Text>(empty)</Text>
                            </li>
                          </ul>
                          <Button
                            onClick={() => {}}
                            color="danger"
                            style={{
                              fontWeight: 'Bold',
                              width: 150,
                              paddingTop: 15,
                              paddingBottom: 15,
                            }}
                          >
                            <Text>KNOW MORE</Text>
                          </Button>
                        </View>
                      </Grid.Box>
                      <Grid.Box size={12} sizeMd={6}>
                        <View
                          style={{
                            width: '98%',
                            boxShadow: '0px 0px 22px -3px rgba(0, 0, 0, 0.75)',
                            backgroundColor: '#fff',
                            borderRadius: 2,
                            padding: 40,
                            marginTop: 40,
                          }}
                        >
                          <Text
                            h4="true"
                            style={{ color: '#e86551', fontWeight: 'bold', fontSize: 20 }}
                          >
                            FUR
                          </Text>
                          <Text
                            h2="true"
                            style={{ color: '#0084a6', fontWeight: 'bold', fontSize: 20 }}
                          >
                            SCHULEN
                          </Text>
                          <ul
                            style={{
                              marginBottom: 40,
                              marginTop: 25,
                            }}
                          >
                            <li>
                              <Text>
                                Bieten Sie Ihren Auszubildenden eine vollig neue Form des
                                gemeinsamen Lernens. Nutzen Sie Tausende von Ubungsaufgaben oder
                                erstellen Sie eigene Inhalte
                              </Text>
                            </li>
                            <li>
                              <Text>
                                Bewahren Sie wertvolles Wissen in lhrem Betrieb-mit
                                Erfahrungsberichten und Gedachtnisprotokollen zu Klaunsuren,
                                Seminaren und vielem mehr erstellen lhre
                              </Text>
                            </li>
                            <li>
                              <Text>(empty)</Text>
                            </li>
                          </ul>
                          <Button
                            onClick={() => {}}
                            color="danger"
                            style={{
                              fontWeight: 'Bold',
                              width: 150,
                              paddingTop: 15,
                              paddingBottom: 15,
                            }}
                          >
                            <Text>KNOW MORE</Text>
                          </Button>
                        </View>
                      </Grid.Box>
                    </Grid>
                  </View>
                </Container>
              </View>

              <View>
                <Container>
                  <View>
                    <Grid>
                      <Grid.Box
                        size={12}
                        sizeMd={6}
                        style={{
                          justifyContent: 'center',
                          alignItems: 'center',
                          marginTop: 40,
                          marginBottom: 30,
                          borderColor: '#d5d5d5',
                          borderRightWidth: 1,
                        }}
                      >
                        <View
                          style={{
                            width: '75%',
                            justifyContent: 'center',
                            alignItems: 'center',
                            textAlign: 'center',
                          }}
                        >
                          <Text
                            h3="true"
                            style={{
                              fontSize: 22,
                              fontWeight: 'bold',
                              color: '#0084a6',
                              width: 260,
                              paddingBottom: 20,
                            }}
                          >
                            Erstelle eine neue Lerngruppe
                          </Text>
                          <Text
                            multiline="true"
                            style={{
                              lineHeight: 28,
                              height: 140,
                            }}
                          >
                            Offentliche Lerngruppe in English order private Lerngruppe fur die
                            Klausar in Rechnugswesen? Erstelle neue Lergnruppe mit wenigen Klicks
                            und lade deine Freunde ein
                          </Text>
                          <Button style={{ padding: 15 }}>
                            <Text>Lerngruppe erstellen</Text>
                          </Button>
                        </View>
                      </Grid.Box>

                      <Grid.Box
                        size={12}
                        sizeMd={6}
                        style={{
                          justifyContent: 'center',
                          alignItems: 'center',
                          textAlign: 'center',
                          marginTop: 40,
                          marginBottom: 30,
                          borderColor: '#d5d5d5',
                          borderLeftWidth: 1,
                        }}
                      >
                        <View
                          style={{
                            width: '75%',
                            justifyContent: 'center',
                            alignItems: 'center',
                          }}
                        >
                          <Text
                            h3="true"
                            style={{
                              fontSize: 22,
                              fontWeight: 'bold',
                              color: '#e86551',
                              width: 260,
                              paddingBottom: 20,
                            }}
                          >
                            Erst einmal reinschnuppern
                          </Text>
                          <Text
                            multiline="true"
                            style={{
                              lineHeight: 28,
                              height: 140,
                              textAlign: 'center',
                            }}
                          >
                            Wenn du erst kurz in eine Lergnruppe reinschnuppern mochtest,{'\n'}dann
                            schau dir unsere Beispielgruppe an.
                          </Text>
                          <Button style={{ padding: 15 }} color="danger">
                            <Text>Zur Beispielgruppe</Text>
                          </Button>
                        </View>
                      </Grid.Box>
                    </Grid>
                  </View>
                </Container>
              </View>
            </View>
          )}
        </Intl>
        <View
          style={{
            paddingBottom: 100,
            borderBottomWidth: 4,
            borderColor: '#0084a6',
          }}
        >
          <View
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: '100%',
            }}
          >
            <Image source="/img/home/bg-video.jpg" label="background" />
          </View>
          <View>
            <Container>
              <View>
                <Text
                  h1="true"
                  style={{
                    color: '#e86551',
                    fontSize: 35,
                    marginTop: 120,
                    justifyContent: 'center',
                    alignItems: 'center',
                    textAlign: 'center',
                  }}
                >
                  Exam<Text style={{ color: '#0084a6' }}>Unity</Text> in 2 Minuten?
                </Text>
              </View>
              <View style={{ minHeight: 400, marginTop: 40 }}>
                <View
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    width: '100%',
                    height: '100%',
                  }}
                >
                  <Image source="/img/home/bg-player-container.png" label="background" />
                </View>
                <View style={{ minHeight: 250, marginTop: 55 }}>
                  <Text style={{ color: '#0084a6' }}>.</Text>
                </View>
              </View>
            </Container>
          </View>
        </View>

        <View
          style={{
            borderTopWidth: 4,
            borderColor: '#0084a6',
          }}
        >
          <View
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: '100%',
            }}
          >
            <Image source="/img/home/bg-cta.jpg" label="background" />
          </View>
          <View>
            <Grid>
              <Grid.Box size={12} sizeMd={7}>
                <Image source="/img/home/img-cta.png" label="background" style={{ width: '94%' }} />
              </Grid.Box>
              <Grid.Box size={12} sizeMd={5} style={{ paddingTop: 70 }}>
                <View
                  sty={{
                    width: '90%',
                    justifyContent: 'center',
                    alignItems: 'center',
                    textAlign: 'center',
                  }}
                >
                  <Text
                    h3="true"
                    style={{
                      paddingLeft: 30,
                      paddingRight: 30,
                      color: '#272e34',
                      fontSize: 32,
                      textAlign: 'center',
                    }}
                  >
                    Auf allen Geraten, im Brower und als App.
                  </Text>
                  <View
                    style={{
                      flexDirection: 'row',
                      flexWrap: 'wrap',
                      marginTop: 25,
                      textAlign: 'center',
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}
                  >
                    <View
                      style={{
                        marginLeft: 20,
                        width: 135,
                        height: 40,
                      }}
                    >
                      <Image source="/img/home/apple_app.png" label="Apple App" />
                    </View>
                    <View
                      style={{
                        marginLeft: 20,
                        width: 135,
                        height: 40,
                      }}
                    >
                      <Image source="/img/home/google_app.png" label="Google App" />
                    </View>
                  </View>
                </View>
              </Grid.Box>
            </Grid>
          </View>
        </View>

        <View style={styles.copmaniesContainer}>
          <Image source="/img/home/esif.png" label="ESIF" style={styles.comapniesLogo} />
          <Image
            source="/img/home/sachsen-anhalt.png"
            label="Sachsen Anhalt"
            style={styles.comapniesLogo}
          />
          <Image
            source="/img/home/investforum.png"
            label="Invest Forum"
            style={styles.comapniesLogo}
          />
          <Image source="/img/home/tugz.png" label="TUGZ" style={styles.comapniesLogo} />
        </View>
      </View>
    </DefaultLayout>
  );
}

export default Home;
