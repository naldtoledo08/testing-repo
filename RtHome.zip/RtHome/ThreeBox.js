// @flow
import React from 'react';
import { Image, View, Viewport, Button, Text } from 'components';
import styles from './Styles';

type Props = {
  logo: React.PropTypes.string,
  buttonText: React.PropTypes.string,
  bgColor: React.PropTypes.string,
  text1: React.PropTypes.string,
  text2: React.PropTypes.string,
  bottomButtonText: React.PropTypes.string,
  last: React.PropTypes.string,
};

function ThreeBox(props: Props) {
  const {
    logo, buttonText, bgColor, text1, text2, bottomButtonText, last,
  } = props;
  const boxColor = bgColor === 'blue' ? styles.backgroundColorBlue : styles.backgroundColorOrange;
  const buttonFontColor = bgColor === 'blue' ? styles.fontColorBlue : styles.fontColorOrange;

  const boxFontColor = last === 'no' ? styles.fontColorWhite : styles.fontColorBlack;
  const contentBGColor = last === 'no' ? {} : { backgroundColor: '#fff' };
  let bottomViewAddCss = {};
  let borderBottom = '#000';
  let paddingTop = 30;
  if (last === 'no') {
    paddingTop = 0;
    if (bgColor === 'blue') {
      borderBottom = '#1290b1';
      bottomViewAddCss = {
        boxShadow: 'inset 0px 20px 51px -13px #007e9e',
      };
    } else {
      borderBottom = '#f19b8d';
      bottomViewAddCss = {
        boxShadow: 'inset 0px 20px 51px -13px #de5b47',
      };
    }
  }

  return (
    <View style={[styles.threeBoxesView, boxColor]}>
      <View style={styles.threeBoxesViewTop}>
        <View style={styles.threeBoxesBG}>
          <Viewport>
            {media => (
              <View>
                {media.isUpMd && (
                  <Image
                    source="/img/home/bg-3-boxes.png"
                    label="background"
                    style={styles.threeBoxesBgImageDesktop}
                  />
                )}
                {media.isDownSm && (
                  <Image
                    label="background"
                    source="/img/home/bg-3-boxes.png"
                    style={styles.threeBoxesBgImageMobile}
                  />
                )}
              </View>
            )}
          </Viewport>
        </View>
        <Image source={logo} label={buttonText} style={styles.threeBoxesLogo} />
        <View>
          <Button style={[styles.threeBoxesButton, buttonFontColor]}>
            <Text>{buttonText}</Text>
          </Button>
        </View>
      </View>

      <View style={[contentBGColor]}>
        <View style={[styles.threeBoxContentView, boxFontColor]}>
          <View
            style={{
              borderBottomWidth: 1,
              borderColor: borderBottom,
              height: 110,
              paddingTop,
            }}
          >
            <Text>{text1}</Text>
          </View>
          <View style={{ paddingTop: 10, height: 130 }}>
            <Text style={{ paddingTop }}>{text2}</Text>
          </View>
        </View>

        {last === 'no' && (
          <View style={[styles.threeBoxesBottomView, bottomViewAddCss]}>
            <Button onClick={() => {}} color="secondary" style={[styles.threeBoxesBottomButton]}>
              <Text style={{ color: '#fff' }}>{bottomButtonText}</Text>
            </Button>
          </View>
        )}

        {last === 'yes' && (
          <View style={[styles.threeBoxesBottomView, bottomViewAddCss]}>
            <Button onClick={() => {}} color="danger" style={[styles.threeBoxesBottomButton]}>
              <Text style={{ color: '#fff' }}>{bottomButtonText}</Text>
            </Button>
          </View>
        )}
      </View>
    </View>
  );
}

export default ThreeBox;
