import { Component, OnInit } from '@angular/core';

import { Locality } from 'app/models/locality';
import { LocalityService } from 'app/services/locality';

@Component({
  selector: 'app-locality',
  templateUrl: './locality.component.html',
  styleUrls: ['./locality.component.scss']
})
export class LocalityComponent implements OnInit {

  localities: Locality[] = [];
  totalCount: Number = 0;
  showProgressIndicator: boolean = false;
  sortField: String = 'name';
  sortOrder: String = 'asc';

  constructor(private localityService: LocalityService) { }

  ngOnInit() {
     this.loadMore();
  }

  loadMore() {    
    this.showProgressIndicator = true;
    this.localityService.list(
      {
        sort : this.sortField,
        order : this.sortOrder,
        offset: this.localities.length
      }
    ).subscribe(
      locality => {

        this.showProgressIndicator = false;
        this.localities = this.localities.concat(locality.data);
        this.totalCount = locality.total;
      }
    );
  }

  sortTable(field){
      this.localities = [];
      this.sortOrder = (this.sortOrder == "asc" && this.sortField == field) ? "desc" : "asc";      
      this.sortField = field;
      this.loadMore();
  }

}