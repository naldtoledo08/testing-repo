import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LocalityComponent } from './locality.component';
import { LocalityFormComponent } from './locality-form/locality-form.component';

const routes: Routes = [
    { path: '', component: LocalityComponent, pathMatch: 'full' },
    { path: 'new', component: LocalityFormComponent },
    { path: ':id', component: LocalityFormComponent },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class LocalityRoutingModule { }
