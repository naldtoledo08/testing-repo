import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LocalityFormComponent } from './locality-form.component';

describe('LocalityFormComponent', () => {
  let component: LocalityFormComponent;
  let fixture: ComponentFixture<LocalityFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LocalityFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LocalityFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
