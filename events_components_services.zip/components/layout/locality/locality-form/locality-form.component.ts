import { Component, OnInit, Output, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HttpErrorResponse} from '@angular/common/http';
import get from 'lodash.get';

import { Locality } from 'app/models/locality';
import { LocalityService } from 'app/services/locality';

import { AlertService } from '../../../../services/alert';
import { ProgressIndicatorComponent } from '../../progress-indicator/progress-indicator.component';

@Component({
  selector: 'app-locality-form',
  templateUrl: './locality-form.component.html',
  styleUrls: ['./locality-form.component.scss']
})
export class LocalityFormComponent implements OnInit {

  @ViewChild('formLocality') formLocality:ElementRef;

  locality: Locality = new Locality();
  errorMessage: String = null;
  showProgressIndicator: boolean = false;

  @Output() photoState;
  isPhotoValid:boolean = true;
  isSubmitted:boolean = false;

  constructor(
    private localityService: LocalityService,
    
    private router: Router,
    private route: ActivatedRoute,
    private alertService: AlertService,
  ) { }

  ngOnInit() {
    // Retrieve partner detail if any
    this.route.params.subscribe(params => {
      const localityId = params['id'];

      // // It means we're adding new partner
      if (!localityId) {
        return;
      }else{       
        this.isSubmitted = true;
      }
      // // We're editing existing, fetch from the server
      this.localityService.get(localityId).subscribe(

        locality => { this.locality = locality; },
        (err: any) => { this.router.navigate(['locality']); }
      );
    });
  }

  onKeyupValidate() {
    var form:any = this.locality;
    this.fonOnKeyupValidate(form.name,'name');
  }

  fonOnKeyupValidate(data,elementId) {
    if(!data || data == "") {
      this.formLocality.nativeElement.querySelector(`#${elementId}`).classList.add('input-error');
    }else {
      this.formLocality.nativeElement.querySelector(`#${elementId}`).classList.remove('input-error');
      return false;  
    }
    return true;
  }

  saveLocality () {
    this.isSubmitted = true;
    this.fonOnKeyupValidate(this.locality.name, 'name');
    if(!this.locality.name || this.locality.name == "" || !this.locality.image || this.locality.image == "") {
       this.alertService.error("Please check all required fields.");
       if(this.locality.image) {
        this.isPhotoValid = true;
      }else {
        this.isPhotoValid = false;
      }
       return false;
    }

    this.showProgressIndicator = true;
    let request: Observable<any>;
    if (this.locality.id) { // Editing
      request = this.localityService.update(this.locality);
    } else { // Creating
      request = this.localityService.save(this.locality);
    }
    request.subscribe(
      data => this.router.navigate(['locality']),
      (err: any) => {
        console.log(err)
        if (err.error instanceof Error) {
          // A client-side or network error occurred. Handle it accordingly.
          console.log('An error occurred:', err.error.message);
        } else {
          this.showProgressIndicator = false;
          const errorResponse = JSON.parse(err._body)
          this.errorMessage = errorResponse.message;
          // console.log(err)
          // The backend returned an unsuccessful response code.
          // The response body may contain clues as to what went wrong,
          // console.log(`Backend returned code ${err.status}, body was: ${err.error}`);
        }
      }
    );
  }

  deleteLocality (localityId: Number) {
    if (confirm('Are you sure you want to delete this locallity?')) {
      this.localityService.delete(localityId).subscribe(resp => {
        // Delete will yield no content, check the status here
        if (resp.status === 204) {
          this.router.navigate(['locality']);
        }
      });
    }
  }

  onUploadPhoto(event: any) {

    const secureUrl = get(event, 'secure_url');
    if (!secureUrl) {
      this.alertService
        .error('Oopps.. something went wrong uploading photo. Please try again.');
    }
    this.locality = {
      ...this.locality,
      ['image']: secureUrl,
    };
    
  }



}
