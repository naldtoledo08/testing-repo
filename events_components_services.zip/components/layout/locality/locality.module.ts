import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PageHeaderModule } from '../page-header';
import { LocalityRoutingModule } from './locality.routing.module';

import { SharedModule } from '../shared/shared.module';

import { LocalityComponent } from './locality.component';

import { LocalityService } from '../../../services/locality';

import { ContractService } from '../../../services/contract';

import { LocalityFormComponent } from './locality-form/locality-form.component';

import { ProgressIndicatorModule } from '../progress-indicator/progress-indicator.module';

@NgModule({
  imports: [
    RouterModule,
    CommonModule,
    LocalityRoutingModule,
    PageHeaderModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    ProgressIndicatorModule,
  ],
  declarations: [
    LocalityComponent,
    LocalityFormComponent,
  ],
  providers: [
    LocalityService,
    ContractService,
  ],
})
export class LocalityModule { }
