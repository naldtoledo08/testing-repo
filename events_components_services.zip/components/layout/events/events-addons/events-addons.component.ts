import { Component, OnInit, Input, EventEmitter, Output } from "@angular/core";
import { AddOn } from "../../../../models/add-on";

@Component({
  selector: "app-events-addons",
  templateUrl: "./events-addons.component.html",
  styleUrls: ["events-addons.component.scss"]
})
export class EventsAddonsComponent implements OnInit {
  addOn: AddOn = new AddOn();
  @Output() addOnModalAction: EventEmitter<any> = new EventEmitter();
  @Input() modalStatus: boolean;
  modalStatusDelay: boolean = false;
  saveBntStatus: boolean = true;
  ngOnInit() {
    this.addOn.price = 0;
    console.log(this.addOn.name);
    if (this.modalStatus == true) {
      setTimeout(() => {
        this.modalStatusDelay = true;
      }, 200);
    }
  }
  closeModal() {
    this.modalStatus = false;
    this.addOnModalAction.emit({
      modalStatus: false,
      action: "close",
      data: {}
    });
  }
  isDirty() {
    if (
      this.addOn.name.trim() === "" ||
      this.addOn.price === 0 ||
      !this.addOn.price
    ) {
      this.saveBntStatus = true;
    } else {
      this.saveBntStatus = false;
    }
  }
  onSubmit() {
    this.addOnModalAction.emit({
      modalStatus: false,
      action: "save",
      data: this.addOn
    });
  }
}
