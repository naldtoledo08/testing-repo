import { EventService } from "../../../services/event";
import { CategoryService } from "../../../services/category/category.service";
import { AccordionModule } from "../accordion/accordion.module";
import { PageHeaderModule } from "../page-header";
import { ProgressIndicatorModule } from "../progress-indicator/progress-indicator.module";
import { SharedModule } from "../shared/shared.module";
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { EventsRoutingModule } from "./events-routing.module";
import { EventsComponent } from "./events.component";
import { EventFormComponent } from "./event-form/event-form.component";
import { FormsModule } from "@angular/forms";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { MomentModule } from "angular2-moment";
import { DateTimePickerModule } from "ng-pick-datetime";
import { AngularMultiSelectModule } from "angular2-multiselect-dropdown/angular2-multiselect-dropdown";
import { CurrencyMaskModule } from "ng2-currency-mask";
import {
  CurrencyMaskConfig,
  CURRENCY_MASK_CONFIG
} from "ng2-currency-mask/src/currency-mask.config";
import { NguiAutoCompleteModule } from "@ngui/auto-complete";
import { EventsAddonsComponent } from "./events-addons/events-addons.component";

export const CustomCurrencyMaskConfig: CurrencyMaskConfig = {
  align: "left",
  allowNegative: true,
  allowZero: true,
  decimal: ".",
  precision: 2,
  prefix: "",
  suffix: "",
  thousands: ","
};

@NgModule({
  imports: [
    CommonModule,
    PageHeaderModule,
    FormsModule,
    SharedModule,
    EventsRoutingModule,
    AccordionModule,
    ProgressIndicatorModule,
    DateTimePickerModule,
    CurrencyMaskModule,
    AngularMultiSelectModule,
    MomentModule,
    NgbModule,
    NguiAutoCompleteModule
  ],
  declarations: [EventsComponent, EventFormComponent, EventsAddonsComponent],
  providers: [
    EventService,
    CategoryService,
    { provide: CURRENCY_MASK_CONFIG, useValue: CustomCurrencyMaskConfig }
  ]
})
export class EventsModule {}
