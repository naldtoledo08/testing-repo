import { EventsComponent } from "./events.component";
import { EventFormComponent } from "./event-form/event-form.component";
import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

const routes: Routes = [
  { path: "", component: EventsComponent, pathMatch: "full" },
  { path: "new", component: EventFormComponent },
  { path: ":id", component: EventFormComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EventsRoutingModule {}
