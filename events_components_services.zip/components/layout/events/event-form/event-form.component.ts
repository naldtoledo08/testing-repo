import { Category } from "../../../../models/category";
import { Component, OnInit, Output } from "@angular/core";
import { Content } from "../../../../models/content";
import { Location } from "../../../../models/location";
import { Locality } from "../../../../models/locality";
import { Series } from "../../../../models/series";
import { AddOn } from "../../../../models/add-on";
import { Subcategory } from "../../../../models/subcategory";
import { AlertService } from "../../../../services/alert";
import { EventService } from "../../../../services/event";
import { CategoryService } from "../../../../services/category/category.service";
import { AccordionGroupComponent } from "../../accordion/accordion-group/accordion-group.component";
import { AccordionComponent } from "../../accordion/accordion.component";
import { ProgressIndicatorComponent } from "../../progress-indicator/progress-indicator.component";
import { ActivatedRoute, Router } from "@angular/router";
import { Observable } from "rxjs";
import get from "lodash.get";
import { MapsAPILoader } from "@agm/core";
// import {} from 'googlemaps';
import { ViewChild, ElementRef, NgZone, AfterViewInit } from "@angular/core";
import { NgIf, NgClass } from "@angular/common";
import * as moment from "moment/moment";
import { Http, Response, Headers, RequestOptions } from "@angular/http";

import { AuthService } from "app/services/auth";

@Component({
  selector: "app-event-form",
  templateUrl: "./event-form.component.html",
  styleUrls: ["./event-form.component.scss"]
})
export class EventFormComponent implements OnInit, AfterViewInit {
  @ViewChild("eventLocation") public locationElement: ElementRef;
  @ViewChild("fromEvent") fromEvent: ElementRef;
  event: Content = new Content();
  categories: Category[] = [];
  subcategories: Subcategory[] = [];
  isAccordionGroupOpen = false;
  daysOfWeekSelection = [];
  multiSelectDropdownSettings = {};
  seriesAccordionHeader: string = "Series";
  inclusionsAccordionHeader: string = "Inclusion";
  addOnAccordionHeader: string = "Add-Ons";
  showProgressIndicator: boolean = false;
  isBliimoAdmin: Boolean = false;
  items: any = [];
  selected: any;

  @Output() modalStatus;
  @Output() photoState;
  isPhotoValid: boolean = true;
  modalState = false;
  isFormInputValid: boolean = false;
  isSubmitted: boolean = false;
  updateListIfEmpty: boolean = false;

  observableSource = (keyword: any): Observable<any[]> => {
    return;
  };

  constructor(
    private eventService: EventService,
    private categoryService: CategoryService,
    private route: ActivatedRoute,
    private router: Router,
    private alertService: AlertService,
    private mapsApiLoader: MapsAPILoader,
    private authService: AuthService,
    private ngZone: NgZone,
    public http: Http
  ) {
    this.observableSource = eventService.observableSource;
  }

  ngOnInit() {
    this.isBliimoAdmin = this.authService.isBliimoAdmin();
    this.route.params.subscribe(params => {
      const selectedId = params["id"];
      if (!selectedId) {
        return;
      }

      this.eventService.get(selectedId).subscribe((data: Content) => {
        this.isSubmitted = true;
        this.event = data;
        this.updateLocalities();
        this.eventService.getseries(selectedId).subscribe(series => {
          this.event.seriesArr = series.data;
          this.formatSeriesInputs(false, false); // load back daysOfWeek to object type
        });
      });
    });

    this.initializeDaysOfWeekSelection();
    this.modalStatus = false;
  }

  ngAfterViewInit() {
    this.initializeGoogleMaps();
    this.loadCategories();
  }

  initializeGoogleMaps() {
    this.mapsApiLoader.load().then(() => {
      const autocomplete = new google.maps.places.Autocomplete(
        this.locationElement.nativeElement
      );

      autocomplete.addListener("place_changed", () => {
        this.ngZone.run(() => {
          const place: google.maps.places.PlaceResult = autocomplete.getPlace();
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }
          const location: Location = new Location();
          location.identifier = place.id;
          location.name = place.name;
          location.lat = place.geometry.location.lat();
          location.lng = place.geometry.location.lng();
          location.address = place.formatted_address;
          this.event.location = location;
          this.fromEvent.nativeElement.querySelector(
            "#location-container"
          ).value =
            "";
          this.fonOnKeyupValidate(this.event.location, "location-container");
        });
      });
    });
  }

  loadCategories() {
    this.categoryService.list().subscribe(categories => {
      this.categories = categories;
      this.loadSubcategories();
    });
  }

  loadSubcategories() {
    if (this.event && this.event.categoryId > 0) {
      this.subcategories = this.categories[
        this.event.categoryId - 1
      ].subcategories;
    }
  }

  initializeDaysOfWeekSelection() {
    this.daysOfWeekSelection = [
      { id: 1, itemName: "MONDAY" },
      { id: 2, itemName: "TUESDAY" },
      { id: 3, itemName: "WEDNESDAY" },
      { id: 4, itemName: "THURSDAY" },
      { id: 5, itemName: "FRIDAY" },
      { id: 6, itemName: "SATURDAY" },
      { id: 7, itemName: "SUNDAY" }
    ];

    this.multiSelectDropdownSettings = {
      singleSelection: false,
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All"
    };
  }
  addSeriesAccordionGroup() {
    const newSeries: Series = new Series();

    let index = 0;
    if (this.event.seriesArr && this.event.seriesArr.length > 0) {
      index = this.event.seriesArr.length + 1;
      newSeries.name = "Series" + index;
      this.event.seriesArr.splice(index, 0, newSeries);
    } else {
      newSeries.name = "Series" + index;
      this.event.seriesArr = [];
      this.event.seriesArr.push(newSeries);
    }
  }

  removeSeriesAccordionGroup() {
    this.event.seriesArr.splice(1, 1);
  }

  addInclusionsAccordionGroup() {
    let index = 0;
    if (this.event.inclusions && this.event.inclusions.length > 0) {
      index = this.event.inclusions.length + 1;
      this.event.inclusions.splice(index, 0, "");
    } else {
      this.event.inclusions = [""];
    }
  }

  removeInclusionsAccordionGroup() {
    this.event.inclusions.splice(1, 1);
  }

  addAddOnsAccordionGroup() {
    //Modal Status
    this.modalState = true;
  }

  getModalData(event) {
    this.modalState = event.modalStatus;
    if (event.action === "save") {
      this.event.addons.push(event.data);
    }
  }

  deleteSelectedAddOn(index, name) {
    if (confirm("Are you sure you want to delete " + name + " addon?")) {
      this.event.addons.splice(index, 1);
    }
  }

  formatSeriesInputs(isEditting = true, isEditStartEnd = true) {
    for (const series of get(this.event, "seriesArr", [])) {
      if (isEditStartEnd) {
        if (series.start) {
          series.start = moment(series.start)
            .utc()
            .format("YYYY-MM-DDTHH:mm:ss");
        }

        if (series.end) {
          series.end = moment(series.end)
            .utc()
            .format("YYYY-MM-DDTHH:mm:ss");
        }
      }

      if (series.daysOfWeek && series.daysOfWeek.length > 0) {
        let daysOfWeek: any[] = [];
        for (const day of series.daysOfWeek) {
          if (isEditting) {
            daysOfWeek.push(day["itemName"]);
          } else {
            daysOfWeek.push({
              id: this.daysOfWeekSelection.find(d => d.itemName == day).id,
              itemName: day
            });
          }
        }
        if (isEditting) {
          series.dayOfWeek = daysOfWeek;
        } else {
          series.daysOfWeek = daysOfWeek;
        }
      }
    }
  }

  // Form Validation
  onKeyupValidate() {
    var form: any = this.event;
    if (this.isSubmitted === true) {
      this.fonOnKeyupValidate(form.title, "title");
      this.fonOnKeyupValidate(form.description, "description");

      this.fonOnKeyupValidate(form.location, "location-container");

      this.fonOnKeyupValidate(form.categoryId, "category");
      this.fonOnKeyupValidate(form.subcategoryId, "subcategory");
      this.fonOnKeyupValidate(form.localities, "localities");
      this.fonOnKeyupValidate(form.units, "units");
      this.fonOnKeyupValidate(form.price, "price");
      this.fonOnKeyupValidate(form.maxPax, "maxPax");
      // this.fonOnKeyupValidate(form.photo,'photo-container');
      this.fonOnKeyupValidate(form.why, "why");
      this.fonOnKeyupValidate(form.inclusions, "inclusions");
      this.fonOnKeyupValidate(form.experience, "experience");
      this.updateLocalities();
    }
  }

  fonOnKeyupValidate(data, elementId) {
    if (!data || data == "") {
      this.fromEvent.nativeElement
        .querySelector(`#${elementId}`)
        .classList.add("input-error");
    } else {
      this.fromEvent.nativeElement
        .querySelector(`#${elementId}`)
        .classList.remove("input-error");
    }
  }

  validateFrom() {
    var errorCount: number = 0;
    var form: any = this.event;
    if (this.isSubmitted === true) {
      errorCount += this.forValidateForm(form.inclusions, "inclusions");
      errorCount += this.forValidateForm(form.experience, "experience");
      errorCount += this.forValidateForm(form.why, "why");
      // errorCount += this.forValidateForm(form.photo,'photo-container');
      if (this.event.photo) {
        this.isPhotoValid = true;
      } else {
        this.isPhotoValid = false;
        errorCount++;
        this.fromEvent.nativeElement.querySelector("#maxPax").scrollIntoView();
      }
      errorCount += this.forValidateForm(form.maxPax, "maxPax");
      errorCount += this.forValidateForm(form.price, "price");
      errorCount += this.forValidateForm(form.units, "units");
      errorCount += this.forValidateForm(form.localities, "localities");
      errorCount += this.forValidateForm(form.subcategoryId, "subcategory");
      errorCount += this.forValidateForm(form.categoryId, "category");
      errorCount += this.forValidateForm(form.location, "location-container");
      errorCount += this.forValidateForm(form.description, "description");
      errorCount += this.forValidateForm(form.title, "title");
      this.updateLocalities();
    }

    if (errorCount === 0) {
      return true;
    } else {
      return false;
    }
  }

  forValidateForm(data, elementId) {
    if (!data || data == "") {
      this.fromEvent.nativeElement
        .querySelector(`#${elementId}`)
        .classList.add("input-error");
      this.fromEvent.nativeElement.querySelector(`#${elementId}`).focus();
      return 1;
    } else {
      this.fromEvent.nativeElement
        .querySelector(`#${elementId}`)
        .classList.remove("input-error");
      return 0;
    }
  }

  saveEvent() {
    this.isSubmitted = true;

    //If true ready to submit
    if (this.validateFrom() === true) {
      this.showProgressIndicator = false;
      this.formatSeriesInputs();
      let request: Observable<any>;
      if (this.event.id) {
        request = this.eventService.update(this.event);
      } else {
        request = this.eventService.save(this.event);
      }
      request.subscribe(
        data => this.router.navigate(["events"]),
        err => {
          this.showProgressIndicator = false;
          //this.alertService.error(err);
          this.alertService.error(
            "Error occured while processing your data. Please contact Bliimo support."
          );
        }
      );
    } else {
      this.alertService.error("Please check all required fields.");
    }
  }

  deleteEvent(eventId: Number) {
    if (confirm("Are you sure you want to delete this event?")) {
      this.eventService.delete(eventId).subscribe(resp => {
        if (resp.status === 204) {
          this.router.navigate(["events"]);
        }
      });
    }
  }

  onUploadPhoto(event: any) {
    const secureUrl = get(event, "secure_url");
    if (!secureUrl) {
      this.alertService.error(
        "Oopps.. something went wrong uploading photo. Please try again."
      );
    }
    this.event = {
      ...this.event,
      photo: secureUrl
    };
  }

  trackByIndex(index: number, obj: any): any {
    return index;
  }

  addItem(item: any) {
    if (item.id) {
      if (!this.event.localities.find(b => b.id === item.id)) {
        //if not exist
        this.event.localities.push(item);
        this.fonOnKeyupValidate(this.event.localities, "localities");
        this.updateLocalities();
      }
      this.selected = null;
    }
  }
  updateLocalities() {
    if (this.event.localities.length == 0) {
      this.updateListIfEmpty = false;
    } else {
      this.updateListIfEmpty = true;
    }
  }

  deleteItem(item: any) {
    this.event.localities.splice(0, 1);
  }

  deleteEventLocalityItem(index, name) {
    this.event.localities.splice(index, 1);
  }

  autocompleListFormatter = (data: any) => {
    let html = `<span >${data.name}</span>`;
    return html; //this._sanitizer.bypassSecurityTrustHtml(html);
  };

  setPrimary(index) {
    const locality = this.event.localities[index];
    this.event.localities.splice(index, 1);
    this.event.localities.unshift(locality);
  }
}
