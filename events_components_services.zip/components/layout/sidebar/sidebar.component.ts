import { AuthService } from '../../../services/auth';
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent implements OnInit {
  isBliimoUser: boolean = false;
  isBliimoAdmin: boolean = false;

  constructor(private authService: AuthService ) { }

  ngOnInit(): void {
    this.isBliimoAdmin = this.authService.isBliimoAdmin()
    this.isBliimoUser = this.authService.isBliimoUser()
  }

  isActive = false;

  eventCalled() {
      this.isActive = !this.isActive;
  }
}
