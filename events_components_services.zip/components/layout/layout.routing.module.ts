import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
  {
    path: '', component: LayoutComponent,
    children: [
      //{ path: 'dashboard', loadChildren: './blank-page/blank-page.module#BlankPageModule' },      
      { path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboardModule' },
      { path: 'blogs', loadChildren: './blogs/blogs.module#BlogsModule' },
      { path: 'partners', loadChildren: './partners/partners.module#PartnersModule' },
      { path: 'events', loadChildren: './events/events.module#EventsModule' },
      { path: 'activities', loadChildren: './activities/activities.module#ActivitiesModule' },
      { path: 'profile', loadChildren: './profile/profile.module#ProfileModule' },
      { path: 'locality', loadChildren: './locality/locality.module#LocalityModule' },      
      { path: 'subcategory', loadChildren: './subcategory/subcategory.module#SubcategoryModule' },
      { path: 'country', loadChildren: './country/country.module#CountryModule' },
      { path: 'transactions', loadChildren: './transactions/transactions.module#TransactionsModule' },
      { path: 'vouchers', loadChildren: './vouchers/vouchers.module#VouchersModule' },
      { path: 'audit-trail', loadChildren: './audit-trail/audit-trail.module#AuditTrailModule' },
      { path: 'admin-users', loadChildren: './admin-users/admin-users.module#AdminUsersModule' },
    ],
  },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class LayoutRoutingModule { }
