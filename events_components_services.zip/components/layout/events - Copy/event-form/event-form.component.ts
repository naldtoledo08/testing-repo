import { Category } from '../../../../models/category';
import { Component, OnInit } from '@angular/core';
import { Event } from '../../../../models/event';
import { Location } from '../../../../models/location';
import { Series } from '../../../../models/series';
import { Subcategory } from '../../../../models/subcategory';
import { AlertService } from '../../../../services/alert';
import { CategoryService } from '../../../../services/category/category.service';
import { EventService } from '../../../../services/event';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import get from 'lodash.get';
import { MapsAPILoader } from '@agm/core';
import {} from '@types/googlemaps';
import { ViewChild, ElementRef, NgZone, AfterViewInit } from '@angular/core';
import { NgIf, NgClass } from '@angular/common';
import * as moment from 'moment/moment';

@Component({
  selector: 'app-event-form',
  templateUrl: './event-form.component.html',
  styleUrls: ['./event-form.component.scss'],
})
  
export class EventFormComponent implements OnInit, AfterViewInit {
  
  @ViewChild('location') public locationElement: ElementRef;
  event: Event = new Event();
  categories: Category[] = [];
  subcategories: Subcategory[] = [];
  isAccordionGroupOpen = false;
  daysOfWeekSelection = [];
  multiSelectDropdownSettings = {};
  seriesAccordionHeader: string = 'Series';
  inclusionsAccordionHeader: string = 'Inclusion';
  showProgressIndicator: boolean = false;
  
  constructor(private eventService: EventService,
    private categoryService: CategoryService,
    private route: ActivatedRoute,
    private router: Router,
    private alertService: AlertService,
    private mapsApiLoader: MapsAPILoader,
    private ngZone: NgZone) {
  }
  
  ngOnInit() {
    this.route.params.subscribe(params => {
      const selectedId = params['id'];
      if (!selectedId) {
        return;
      }
      this.eventService.get(selectedId)
        .subscribe((data: Event) => this.event = data);
    });
    
    this.addSeriesAccordionGroup();
    this.initializeDaysOfWeekSelection();
  }
  
  ngAfterViewInit() {
       this.initializeGoogleMaps(); 
       this.loadCategories();
  }
  
  loadCategories() {
     this.categoryService.list().subscribe(categories => {
        this.categories = categories;
        this.loadSubcategories();
     });
  }
  
  loadSubcategories() {
    if (this.event && this.event.categoryId > 0) {
      this.subcategories = this.categories[this.event.categoryId - 1].subcategories;
    } 
  }
  
  initializeGoogleMaps() {
    this.mapsApiLoader.load().then(
      () => {
        const autocomplete = new google.maps.places.Autocomplete(this.locationElement.nativeElement, 
                             { types: ['address'] });

        autocomplete.addListener('place_changed', () => {
          this.ngZone.run(() => {
            const place: google.maps.places.PlaceResult = autocomplete.getPlace();
            if (place.geometry === undefined || place.geometry === null) {
              return;
            }
            const location: Location = new Location();
            location.identifier = place.id;
            location.name = place.name;
            location.lat = place.geometry.location.lat();
            location.lng = place.geometry.location.lng();
            location.address = place.formatted_address;
            this.event.location = location;
            
          });
        });
      },
    );
  }
  
  initializeDaysOfWeekSelection() {
   this.daysOfWeekSelection = [
     { 'id': 1, 'itemName': 'MONDAY' },
     { 'id': 2, 'itemName': 'TUESDAY' },
     { 'id': 3, 'itemName': 'WEDNESDAY' },
     { 'id': 4, 'itemName': 'THURSDAY' },
     { 'id': 5, 'itemName': 'FRIDAY' },
     { 'id': 6, 'itemName': 'SATURDAY' },
     { 'id': 7, 'itemName': 'SUNDAY' },
   ];
   
   this.multiSelectDropdownSettings = {
     singleSelection: false,
     selectAllText: 'Select All',
     unSelectAllText: 'UnSelect All',
   };  
 } 
 
  addSeriesAccordionGroup() {
    const newSeries: Series = new Series();

    let index = 0;
    if (this.event.seriesArr && this.event.seriesArr.length > 0) {
      index = this.event.seriesArr.length + 1;
      this.event.seriesArr.splice(index, 0, newSeries);
    } else {
      this.event.seriesArr = [];
      this.event.seriesArr.push(newSeries);
    }

  }

  removeSeriesAccordionGroup() {
    this.event.seriesArr.splice(1, 1);
  }

  addInclusionsAccordionGroup() {

    let index = 0;
    if (this.event.inclusions && this.event.inclusions.length > 0) {
      index = this.event.inclusions.length + 1;
      this.event.inclusions.splice(index, 0, '');
    } else {
      this.event.inclusions = ['']; 
    }

  }

  removeInclusionsAccordionGroup() {
    this.event.inclusions.splice(1, 1);
  }
  
 formatSeriesInputs() {
   for (const series of this.event.seriesArr) {
     
     if (series.start) {
       series.start = moment(series.start).utc().format('YYYY-MM-DDTHH:mm:ss');
     }
     
     if (series.end) {
       series.end = moment(series.end).utc().format('YYYY-MM-DDTHH:mm:ss');
     }
     
     const daysOfWeek: string[] = [];
     if (series.daysOfWeek && series.daysOfWeek.length > 0) {
       for (const day of series.daysOfWeek) {
         daysOfWeek.push(day['itemName']);
       }
       series.daysOfWeek = daysOfWeek;
     }
   }
 }   

  saveEvent() {
    this.showProgressIndicator = true;
    this.formatSeriesInputs();
    
    let request: Observable<any>;
    if (this.event.id) {
      request = this.eventService.update(this.event);
    } else {
      request = this.eventService.save(this.event);
    }
    request.subscribe(
        data => this.router.navigate(['events']),
        err => {
            this.showProgressIndicator = false;
            this.alertService.error(err);
            },
        );
  }

  deleteEvent(eventId: Number) {
    if (confirm('Are you sure you want to delete this event?')) {
      this.eventService.delete(eventId).subscribe(resp => {
        if (resp.status === 204) {
          this.router.navigate(['events']);
        }
      });
    }
  }
  
  onUploadPhoto(event: any) {
    const secureUrl = get(event, 'secure_url');
    if (!secureUrl) {
      this.alertService
        .error('Oopps.. something went wrong uploading photo. Please try again.');
    }
    this.event = {
      ...this.event,
      photo: secureUrl,
    };
  }
  
  trackByIndex(index: number, obj: any): any {
    return index;
  }

}
