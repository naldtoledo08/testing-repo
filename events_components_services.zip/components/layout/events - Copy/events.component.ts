import { EventService } from '../../../services/event';
import { Component, OnInit } from '@angular/core';
import { Event } from '../../../models/event';
import { AuthService } from '../../../services/auth';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.scss'],
})
export class EventsComponent implements OnInit {
  events: Event[] = [];
  isMerchantUser: false;

  constructor(private eventService: EventService,
              private authService: AuthService) { }

  ngOnInit() {
     this.eventService.list().subscribe(events => this.events = events.data);
     this.isMerchantUser = this.authService.isMerchantUser()
  }

}
