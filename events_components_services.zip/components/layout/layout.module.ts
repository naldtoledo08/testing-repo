import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';

import { LayoutRoutingModule } from './layout.routing.module';
import { LayoutComponent } from './layout.component';

import { HeaderComponent } from './header';
import { SidebarComponent } from './sidebar';
import { AccordionComponent } from './accordion/accordion.component';
import { AccordionGroupComponent } from './accordion/accordion-group/accordion-group.component';

import { PartnerService } from '../../services/partner';
@NgModule({
  imports: [
    CommonModule,
    NgbDropdownModule.forRoot(),
    LayoutRoutingModule,
  ],
  declarations: [
    LayoutComponent,
    HeaderComponent,
    SidebarComponent,
  ],
  providers:[
    PartnerService
  ]
})
export class LayoutModule { }
