import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PageHeaderModule } from '../page-header';
import { VouchersRoutingModule } from './vouchers.routing.module';

import { SharedModule } from '../shared/shared.module';

import { VouchersComponent } from './vouchers.component';

import { VoucherService } from '../../../services/voucher';

@NgModule({
  imports: [
    RouterModule,
    CommonModule,
    VouchersRoutingModule,
    PageHeaderModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
  ],
  declarations: [
    VouchersComponent,
  ],
  providers: [
    VoucherService,
  ],
})
export class VouchersModule { }
