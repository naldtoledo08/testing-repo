import { Component, OnInit } from '@angular/core';

import { Voucher } from '../../../models/voucher';
import { VoucherService } from '../../../services/voucher';

@Component({
  selector: 'app-vouchers',
  templateUrl: './vouchers.component.html',
  styleUrls: ['./vouchers.component.scss']
})
export class VouchersComponent implements OnInit {

  vouchers: Voucher[] = [];
  totalCount: number = 0;

  constructor(private voucherService: VoucherService) { }

  ngOnInit() {
    this.loadMore();
  }

  loadMore() {
    this.voucherService.list({
      offset: this.vouchers.length,
    }).subscribe(
      vouchers => {
        this.vouchers = this.vouchers.concat(vouchers.data);
        this.totalCount = vouchers.total;
      }
    );
  }

}
