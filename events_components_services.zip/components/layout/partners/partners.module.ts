import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PageHeaderModule } from '../page-header';
import { PartnersRoutingModule } from './partners.routing.module';

import { SharedModule } from '../shared/shared.module';

import { PartnersComponent } from './partners.component';

import { PartnerService } from '../../../services/partner';
import { AdminService } from '../../../services/admin';
import { ContractService } from '../../../services/contract';
import { PartnerFormComponent } from './partner-form/partner-form.component';
import { ProgressIndicatorModule } from '../progress-indicator/progress-indicator.module';

import { ModalComponent } from '../modal/modal.component';
@NgModule({
  imports: [
    RouterModule,
    CommonModule,
    PartnersRoutingModule,
    PageHeaderModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    ProgressIndicatorModule,
  ],
  declarations: [
    PartnersComponent,
    PartnerFormComponent,
    ModalComponent
  ],
  providers: [
    PartnerService,
    ContractService,
    AdminService,
  ],
})
export class PartnersModule { }
