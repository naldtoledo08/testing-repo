import { Component, OnInit, Output} from '@angular/core';

import { Partner } from '../../../models/partner';
import { PartnerService } from '../../../services/partner';
import { AuthService } from '../../../services/auth';
import { AdminService } from '../../../services/admin';

import { NgIf, NgClass } from '@angular/common';
import { Observable } from 'rxjs';
import { AlertService } from '../../../services/alert';

@Component({
  selector: 'app-partners',
  templateUrl: './partners.component.html',
  styleUrls: ['./partners.component.scss']
})
export class PartnersComponent implements OnInit {

  partners: Partner[] = [];
  sortField: String = 'name';
  sortOrder: String = 'asc';
  totalCount: Number = 0;

  status: String = '';
  partnerStatus: String = '';
  applicationStatus: String = '';  

  isBliimoAdmin: Boolean = false;
  isMerchantUser: Boolean = false;  
  showProgressIndicator: boolean = false;

  selectedCount:number;
  errorCount:number = 0;
  batchPartners: Partner[] =[];
  partner: Partner = new Partner();
  batchTogglerClass:string = 'hide';  
  
  listToggler:string = 'hide';

  @Output() modalStatus;
  @Output() modalMessage;
  @Output() modalError;
  modalState :boolean = false;
  alertMessage: string ="";
  modalHeader: string ="Partner";

  constructor(
    private authService: AuthService,
    private partnerService: PartnerService,
    private adminService: AdminService,
    private alertService: AlertService,
  ) { }

  ngOnInit() {
    this.isBliimoAdmin = this.authService.isBliimoAdmin();
    this.isMerchantUser = this.authService.isMerchantUser();
    this.loadMore();
  }

  impersonate (identifier: String) {
    this.adminService.impersonate(
      identifier
    ).subscribe(
      result => {
        window.open(result, "_blank");
      },
      (err: any) => {
        alert('We have found issue authenticating.');
      }
    );
  }

  loadMore() {    
    this.showProgressIndicator = true;
    this.alertService.clearMessage();

    this.partnerService.list(
      {
        sort : this.sortField,
        order: this.sortOrder,
        offset: this.partners.length,
        partnerStatus: this.partnerStatus,
        applicationStatus: this.applicationStatus
      }
    ).subscribe(
      partners => {        
        this.showProgressIndicator = false;
        this.partners = this.partners.concat(partners.data);
        this.totalCount = partners.total;
      }
    );
  }

  sortTable(field){
      this.alertService.clearMessage();
      this.batchPartners = [];
      this.partners = [];
      this.sortOrder = (this.sortOrder == "asc" && this.sortField == field) ? "desc" : "asc";      
      this.sortField = field;
      this.loadMore();
  }

  updateErrorCount(partner, type){
    if(!partner.payoutAccount || !partner.bankTypeCode){
      this.errorCount += (type == "add") ? 1 : -1;
    }
  }
 
  clickPartners(index, partner){    
    
    if(this.isBliimoAdmin && this.status != ''){
      this.alertService.clearMessage();
      if(typeof this.batchPartners[index] !== 'undefined'){
        //not recommended but needed to use to retain indexing, splice won't
        delete this.batchPartners[index];
        this.updateErrorCount(partner, "remove");
      }else{
        this.batchPartners[index]=partner;        
        this.updateErrorCount(partner, "add");
      }

      this.batchTogglerClass = 'hide';
      //Workaround for deleting item in array since delete retain the count
      let countItems = 0;
      this.batchPartners.forEach(element => {
         if(element) {
          //this.listBatchList = element
          this.batchTogglerClass = 'show';
          countItems++;
         }
      });
      if(countItems === 0) {
        this.listToggler = 'hide';
      }
      this.selectedCount = countItems;
    }
  }

  toggleShowMiniList() {
    this.listToggler = (this.listToggler === 'hide' ? 'show' : 'hide' );
  }
  closeToggledList() {
    this.listToggler = 'hide';
  }

  batchChangeSubStatus(status, column){
    var count = 0;
    var length = this.selectedCount;

    if(this.errorCount > 0 && status == "ACCEPTED"){

      this.alertService.error(this.errorCount+" Partner(s) don't have their Bank Type, Payout Account. Please check before doing this action.");
    
    }else{

      for (var i in this.batchPartners) {
        count++;
        this.partner = this.batchPartners[i];
        //this.partner['applicationStatus'] = status;
        this.partner[column] = status;
        this.showProgressIndicator = true;

        let request: Observable<any>;
        request = this.partnerService.update(this.partner);
        request.subscribe(
          data => {
            delete this.batchPartners[i];
            if(count >= this.selectedCount){
              this.batchPartners = [];
              this.selectedCount = 0;
              this.batchTogglerClass = 'hide';
              this.closeToggledList();
              this.showProgressIndicator = false;
              var type = (count > 1) ? "Partners" : "Partner";  
              this.alertService.success(length+" " + type +" Successfully "+ status);
            }
          },
          err => {
              this.showProgressIndicator = false;
              this.alertService.error("Error occur while updating your data.");
              },
          );
      }
    }
    
  }

  changeDisplayLevel(event){
    this.status = event.target.value;
    switch (this.status) {
      case "ACTIVE":
        this.partnerStatus = 'ACTIVE';
        this.applicationStatus = '';
        break;
      case "INACTIVE":
        this.partnerStatus = 'INACTIVE';
        this.applicationStatus = '';
        break;
      case "PENDING":
        this.partnerStatus = '';
        this.applicationStatus = 'PENDING';
        break;
      case "DECLINED":
        this.partnerStatus = '';
        this.applicationStatus = 'DECLINED';
        break;
      case "ACCEPTED":        
        this.partnerStatus = '';
        this.applicationStatus = 'ACCEPTED';
        break;      
      default:
        this.partnerStatus = '';
        this.applicationStatus = '';
        break;
    }
    this.batchPartners = [];
    this.partners = [];
    this.batchTogglerClass = 'hide';
    this.loadMore();
  }

  getModalEvent(event) {
    this.modalState = event.modalStatus;
    this.alertMessage = event.modalMessage;
  }

  showInfo(partner){
    this.modalState = true;
    var _info = "";
    _info +="<div class='row'><label for='owner' class='col-sm-3 col-form-label'>Owner : </label>";
    _info +="<div class='col-sm-9'>"+ partner.owner + "</div>";
    _info +="</div>";

    _info +="<div class='row'><label for='location' class='col-sm-3 col-form-label'>Location : </label>";
    _info +="<div class='col-sm-9'>"+ partner.location.address + "</div>";
    _info +="</div>";

    _info +="<div class='row'><label for='email' class='col-sm-3 col-form-label'>Email : </label>";
    _info +="<div class='col-sm-9'>"+ partner.email + "</div>";
    _info +="</div>";

    _info +="<div class='row'><label for='phone' class='col-sm-3 col-form-label'>Phone : </label>";
    _info +="<div class='col-sm-9'>"+ partner.phone + "</div>";
    _info +="</div>";

    _info +="<div class='row'><label for='identifier' class='col-sm-3 col-form-label'>Partner ID : </label>";
    _info +="<div class='col-sm-9'>"+ partner.identifier + "</div>";
    _info +="</div>";

    _info +="<div class='row'><label for='bankTypeDesc' class='col-sm-3 col-form-label'>Bank Type: </label>";
    _info +="<div class='col-sm-9'>"+ partner.bankTypeDesc + "</div>";
    _info +="</div>";

    _info +="<div class='row'><label for='payoutAccount' class='col-sm-3 col-form-label'>Payout Account: </label>";
    _info +="<div class='col-sm-9'>"+ partner.payoutAccount + "</div>";
    _info +="</div>";

    _info +="<div class='row'><label for='enrolledBy' class='col-sm-3 col-form-label'>Enrolled by: </label>";
    _info +="<div class='col-sm-9'>"+ partner.enrolledBy.fullName + "</div>";
    _info +="</div>";

    _info +="<div class='row'><label for='description' class='col-sm-3 col-form-label'>About : </label>";
    _info +="<div class='col-sm-9'>"+ partner.description + "</div>";
    _info +="</div>";

    this.alertMessage = _info;
    this.modalHeader = "Partner - " + partner.name;
    console.log(partner);   
    return false;
  }

  
}
