import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PartnersComponent } from './partners.component';
import { PartnerFormComponent } from './partner-form/partner-form.component';

const routes: Routes = [
    { path: '', component: PartnersComponent, pathMatch: 'full' },
    { path: 'new', component: PartnerFormComponent },
    { path: ':id', component: PartnerFormComponent },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class PartnersRoutingModule { }
