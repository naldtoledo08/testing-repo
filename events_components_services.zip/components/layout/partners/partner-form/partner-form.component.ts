import { Component, OnInit, ViewChild, ElementRef, NgZone, AfterViewInit, Output } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HttpErrorResponse} from '@angular/common/http';
import get from 'lodash.get';

import { MapsAPILoader } from '@agm/core';

import { Location } from '../../../../models/location';
import { Partner } from '../../../../models/partner';
import { Contract } from '../../../../models/contract';
import { DropDown } from '../../../../models/dropdown';

import { PartnerService } from '../../../../services/partner';
import { ContractService } from '../../../../services/contract';

import { AlertService } from '../../../../services/alert';
import { ProgressIndicatorComponent } from '../../progress-indicator/progress-indicator.component';

@Component({
  selector: 'app-partner-form',
  templateUrl: './partner-form.component.html',
  styleUrls: ['./partner-form.component.scss']
})
export class PartnerFormComponent implements OnInit {

  @ViewChild('partnerLocation') public locationElement: ElementRef;
  partner: Partner = new Partner();
  contracts: Contract[] = [];
  bankTypeCodesArray : any = []
  bankTypeCodes: DropDown[] = [];
  payOutName: string = "";

  errorMessage: String = null;
  showProgressIndicator: boolean = false;

  @Output() modalStatus;
  @Output() modalMessage;
  @Output() modalError;
  modalState :boolean = false;
  alertMessage: string ="";
  constructor(
    private partnerService: PartnerService,
    private contractService: ContractService,
    private router: Router,
    private route: ActivatedRoute,
    private alertService: AlertService,
    private mapsApiLoader: MapsAPILoader,
    private ngZone: NgZone,
  ) { }

  ngOnInit() {
    // Retrieve partner detail if any
    this.route.params.subscribe(params => {
      const partnerId = params['id'];
      // It means we're adding new partner
      if (!partnerId) {
        return;
      }
      // We're editing existing, fetch from the server
      this.partnerService.get(partnerId).subscribe(
        partner => { this.partner = partner;
          this.payOutName = (this.partner.bankTypeCode != "") ? " - "+this.bankTypeCodesArray[this.partner.bankTypeCode] : "";
        },
        (err: any) => { this.router.navigate(['partners']); }
      );
    });

    // Retrieve all the possible contracts to assign to merchants
    this.contractService.list().subscribe(
      contracts => {
        this.contracts = contracts.data;
      }
    );
    this.loadBankTypeCodes();
  }

  getModalEvent(event) {
    this.modalState = event.modalStatus;
    this.alertMessage = event.modalMessage;
  }

  savePartner () {
    if(!this.partner.payoutAccount || !this.partner.bankTypeCode){
      this.modalState = true;
      this.alertMessage = "Bank Type and Pay Account should not be empty.";
    }else{

      this.showProgressIndicator = true;
      let request: Observable<any>;
      if (this.partner.id) { // Editing
        request = this.partnerService.update(this.partner);
      } else { // Creating
        request = this.partnerService.save(this.partner);
      }
      request.subscribe(
        data => this.router.navigate(['partners']),
        (err: any) => {
          console.log(err)
          if (err.error instanceof Error) {
            // A client-side or network error occurred. Handle it accordingly.
            console.log('An error occurred:', err.error.message);
          } else {
            this.showProgressIndicator = false;
            const errorResponse = JSON.parse(err._body)
            this.errorMessage = errorResponse.message
            // console.log(err)
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            // console.log(`Backend returned code ${err.status}, body was: ${err.error}`);
          }
        }
      );
    }
  }

  ngAfterViewInit() {
    this.initializeGoogleMaps();
    
  }

  initializeGoogleMaps() {
    this.mapsApiLoader.load().then(
      () => {
        const autocomplete = new google.maps.places.Autocomplete(this.locationElement.nativeElement,
                             { types: ['address'] });

        autocomplete.addListener('place_changed', () => {
          this.ngZone.run(() => {
            const place: google.maps.places.PlaceResult = autocomplete.getPlace();
            if (place.geometry === undefined || place.geometry === null) {
              return;
            }
            const location: Location = new Location();
            location.identifier = place.id;
            location.name = place.name;
            location.lat = place.geometry.location.lat();
            location.lng = place.geometry.location.lng();
            location.address = place.formatted_address;
            this.partner.location = location;
          });
        });
      },
    );
  }

  deletePartner (partnerId: Number) {
    if (confirm('Are you sure you want to delete this partner?')) {
      this.partnerService.delete(partnerId).subscribe(resp => {
        // Delete will yield no content, check the status here
        if (resp.status === 204) {
          this.router.navigate(['partners']);
        }
      });
    }
  }

  onUpload(event: any) {
    const secureUrl = get(event, 'secure_url');
    if (!secureUrl) {
      this.alertService
        .error('Oopps.. something went wrong uploading photo. Please try again.');
    }
    this.partner = {
      ...this.partner,
      [event.type]: secureUrl,
    };
  }

  loadBankTypeCodes(){
    this.bankTypeCodes =  [
      { id: "AUB", name: "Asia United Bank CA/SA (limited)" },
      { id: "BDO", name: "Banco de Oro CA/SA" },
      { id: "BPI", name: "BPI CA/SA"},
      { id: "CBC", name: "Chinabank CA/SA"},
      { id: "EWB", name: "Eastwest CA/SA"},
      { id: "LBP", name: "Landbank CA/SA"},
      { id: "MBTC", name:"Metrobank CA/SA"},
      { id: "PNB", name: "PNB individual CA/SA"},
      { id: "RCBC", name: "RCBC CA/SA, RCBC Savings Bank CA/SA, RCBC MyWallet"},
      { id: "SBC", name: "Security Bank CA/SA"},
      { id: "UBP", name: "Unionbank CA/SA, EON"},
      { id: "UCPB", name: "UCPB CA/SA"},
      { id: "CEBL", name: "Cebuana Lhuillier Cash Pick-up"},
      { id: "PSB", name: "PSBank CA/SA (reserved)"},
      { id: "GCSH", name: "Gcash"},
      { id: "SMRT", name: "Smart Money (reserved)"}
    ];
    this.loadbankTypeCodesArray();
  }

  loadbankTypeCodesArray(){
    for(var x = 0; x < this.bankTypeCodes.length; x++){
        this.bankTypeCodesArray[this.bankTypeCodes[x].id] = this.bankTypeCodes[x].name;
    }  
  }

  loadPayoutName(obj){
    this.payOutName = " - "+this.bankTypeCodesArray[obj];
    this.partner.payoutAccount = "";
  }

}
