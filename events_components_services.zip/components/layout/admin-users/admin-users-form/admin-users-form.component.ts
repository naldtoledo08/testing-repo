import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HttpErrorResponse} from '@angular/common/http';

import { Admin } from '../../../../models/admin';

import { AlertService } from '../../../../services/alert';
import { AdminService } from '../../../../services/admin';

import { ProgressIndicatorComponent } from '../../progress-indicator/progress-indicator.component';

@Component({
  selector: 'app-admin-users-form',
  templateUrl: './admin-users-form.component.html',
  styleUrls: ['./admin-users-form.component.scss']
})
export class AdminUsersFormComponent implements OnInit {

  admin: Admin = new Admin();
  errorMessage: String = null;
  showProgressIndicator: boolean = false;
  adminRoles: String[] = ['ROLE_BACKOFFICE_ADMIN', 'ROLE_BACKOFFICE_USER', 'ROLE_BACKOFFICE_SALES'];

  constructor(
    private adminService: AdminService,
    private alertService: AlertService,
    private router: Router,
    private route: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      const adminId = params['id'];
      // It means we're adding new partner
      if (!adminId) {
        return;
      }
      // We're editing existing, fetch from the server
      this.adminService.get(adminId).subscribe(
        admin => { this.admin = admin; },
        (err: any) => { this.router.navigate(['/admin-users']); }
      );
    });
  }

  toRole(role) {
    const rolesMapping = {
      'ROLE_BACKOFFICE_ADMIN': 'Administrator',
      'ROLE_BACKOFFICE_USER': 'Staff',
      'ROLE_BACKOFFICE_SALES': 'Sales'
    };
    return rolesMapping[role];
  }

  onToggle(event, role) {
    const RBA = 'ROLE_BACKOFFICE_ADMIN';
    if(event.target.checked) {
      this.admin.roles = role === RBA ? this.adminRoles : this.admin.roles.concat(role);
    } else {
      this.admin.roles = this.admin.roles.filter(ar => ar  !== role)
    }
  }

  saveAdmin() {
    if ((this.admin.password || this.admin.confirmPassword) && this.admin.password !== this.admin.confirmPassword) {
      alert("Password mismatch");
      return;
    }

    this.showProgressIndicator = true;
    let request: Observable<any>;
    if (this.admin.id) { // Editing
      request = this.adminService.update(this.admin);
    } else { // Creating
      request = this.adminService.save(this.admin);
    }
    request.subscribe(
      data => this.router.navigate(['admin-users']),
      (err: any) => {
        console.log(err)
        if (err.error instanceof Error) {
          // A client-side or network error occurred. Handle it accordingly.
          console.log('An error occurred:', err.error.message);
        } else {
          this.showProgressIndicator = false;
          const errorResponse = JSON.parse(err._body)
          this.errorMessage = errorResponse.message
        }
      }
    );
  }

}
