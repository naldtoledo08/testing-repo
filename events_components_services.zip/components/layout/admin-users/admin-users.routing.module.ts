import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdminUsersComponent } from './admin-users.component';
import { AdminUsersFormComponent } from './admin-users-form/admin-users-form.component';

const routes: Routes = [
    { path: '', component: AdminUsersComponent, pathMatch: 'full' },
    { path: 'new', component: AdminUsersFormComponent },
    { path: ':id', component: AdminUsersFormComponent },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class AdminUsersRoutingModule { }
