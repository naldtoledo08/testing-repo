import { Component, OnInit } from '@angular/core';

import { Admin } from '../../../models/admin';
import { AdminService } from '../../../services/admin';
import { AlertService } from '../../../services/alert';

@Component({
  selector: 'app-admin-users',
  templateUrl: './admin-users.component.html',
  styleUrls: ['./admin-users.component.scss']
})

export class AdminUsersComponent implements OnInit {

  admins: Admin[] = [];

  constructor(
    private adminService: AdminService,
    private alertService: AlertService
  ) { }

  ngOnInit() {
    this.adminService.list(
      {
        sort: 'username',
        order: 'asc'
      }
    ).subscribe(
      admins => {
        this.admins = admins.data;
      }
    );
  }

  toRoles(roles) {
    const rolesMapping = {
      'ROLE_BACKOFFICE_ADMIN': 'Administrator',
      'ROLE_BACKOFFICE_USER': 'Staff',
      'ROLE_BACKOFFICE_SALES': 'Sales'
    };
    if (!roles || roles.length == 0) return ''
    return roles.map(role => rolesMapping[role])
  }

}
