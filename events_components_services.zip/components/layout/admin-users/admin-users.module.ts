import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PageHeaderModule } from '../page-header';
import { AdminUsersRoutingModule } from './admin-users.routing.module';

import { SharedModule } from '../shared/shared.module';

import { AdminUsersComponent } from './admin-users.component';

import { AdminService } from '../../../services/admin';
import { AdminUsersFormComponent } from './admin-users-form/admin-users-form.component';
import { ProgressIndicatorModule } from '../progress-indicator/progress-indicator.module';

@NgModule({
  imports: [
    RouterModule,
    CommonModule,
    AdminUsersRoutingModule,
    PageHeaderModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    ProgressIndicatorModule,
  ],
  declarations: [
    AdminUsersComponent,
    AdminUsersFormComponent,
  ],
  providers: [
    AdminService,
  ],
})
export class AdminUsersModule { }
