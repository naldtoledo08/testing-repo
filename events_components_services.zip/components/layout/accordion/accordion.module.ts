import { AccordionGroupComponent } from './accordion-group/accordion-group.component';
import { AccordionComponent } from './accordion.component';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';

@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [
    AccordionComponent,
    AccordionGroupComponent,
  ],
  exports: [ 
     AccordionComponent, 
     AccordionGroupComponent,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AccordionModule { }
