import { Component, OnInit, Input, EventEmitter,Output } from '@angular/core';

@Component({
    selector: 'app-modal',
    templateUrl: './modal.component.html',
    styleUrls: ['modal.component.scss']
})

export class ModalComponent implements OnInit{
    @Output() modalAction: EventEmitter<any> = new EventEmitter();
    @Input() modalStatus:boolean;
    @Input() modalMessage:string = "Hello";
    @Input() modalError:boolean = false;
    @Input() modalTitle:string = "Message";
    modalStatusDelay:boolean = false;
    saveBntStatus:boolean = true;
    title:string;
    //message: string = "Hello";
    ngOnInit() {
        this.title = this.modalTitle;
        if(this.modalStatus == true) {
            setTimeout(() => {
                this.modalStatusDelay = true;
            }, 200);
        }
    }
    closeModal() {
        this.modalStatus = false;
        this.modalAction.emit({'modalStatus':false,'action':'close','data':{}});
    }    
}