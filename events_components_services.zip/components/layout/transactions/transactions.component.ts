import { Component, OnInit } from '@angular/core';

import { Transaction } from '../../../models/transaction';
import { TransactionService } from '../../../services/transaction';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.scss']
})
export class TransactionsComponent implements OnInit {

  transactions: Transaction[] = [];

  totalCount: Number = 0;
  showProgressIndicator: boolean = false;
  sortField: String = 'dateCreated';
  sortOrder: String = 'desc';

  constructor(private transactionService: TransactionService) { }

  ngOnInit() {    
     this.loadMore();
  }

  loadMore() {    
    this.showProgressIndicator = true;
    this.transactionService.list(
      {
        sort : this.sortField,
        order : this.sortOrder,
        offset: this.transactions.length
      }
    ).subscribe(
      transactions => {

        this.showProgressIndicator = false;
        this.transactions = this.transactions.concat(transactions.data);
        this.totalCount = transactions.total;
      }
    );
  }

   sortTable(field){
      this.transactions = [];
      this.sortOrder = (this.sortOrder == "asc" && this.sortField == field) ? "desc" : "asc";      
      this.sortField = field;
      this.loadMore();
  }

}
