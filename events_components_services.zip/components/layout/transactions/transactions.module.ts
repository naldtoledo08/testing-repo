import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PageHeaderModule } from '../page-header';
import { TransactionsRoutingModule } from './transactions.routing.module';

import { SharedModule } from '../shared/shared.module';

import { TransactionsComponent } from './transactions.component';

import { TransactionService } from '../../../services/transaction';

import { ProgressIndicatorModule } from '../progress-indicator/progress-indicator.module';

@NgModule({
  imports: [
    RouterModule,
    CommonModule,
    TransactionsRoutingModule,
    PageHeaderModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    ProgressIndicatorModule
  ],
  declarations: [
    TransactionsComponent,
  ],
  providers: [
    TransactionService,
  ],
})
export class TransactionsModule { }
