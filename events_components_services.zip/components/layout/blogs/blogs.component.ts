import { Component, OnInit } from '@angular/core';

import { Blog } from '../../../models/blog';
import { BlogService } from '../../../services/blog';

@Component({
  selector: 'app-blogs',
  templateUrl: './blogs.component.html',
  styleUrls: ['./blogs.component.scss'],
})
export class BlogsComponent implements OnInit {

  blogs: Blog[] = [];
  totalCount: Number = 0;
  showProgressIndicator: boolean = false;
  sortField: String = 'dateCreated';
  sortOrder: String = 'desc';

  constructor(private blogService: BlogService) { }
  ngOnInit() {
    this.loadMore();
  }

  loadMore() {    
    this.showProgressIndicator = true;
    this.blogService.list(
      {
        sort : this.sortField,
        order : this.sortOrder,
        offset: this.blogs.length
      }
    ).subscribe(
      blogs => {

        this.showProgressIndicator = false;
        this.blogs = this.blogs.concat(blogs.data);
        this.totalCount = blogs.total;
      }
    );
  }

  sortTable(field){
      this.blogs = [];
      this.sortOrder = (this.sortOrder == "asc" && this.sortField == field) ? "desc" : "asc";      
      this.sortField = field;
      this.loadMore();
  }
}