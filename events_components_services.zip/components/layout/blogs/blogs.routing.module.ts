import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BlogsComponent } from './blogs.component';
import { BlogFormComponent } from './blog-form/blog.form.component';

const routes: Routes = [
    { path: '', component: BlogsComponent, pathMatch: 'full' },
    { path: 'new', component: BlogFormComponent },
    { path: ':id', component: BlogFormComponent },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class BlogsRoutingModule { }
