import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import get from 'lodash.get';

import { Blog } from '../../../../models/blog';
import { BlogService } from '../../../../services/blog';
import { AlertService } from '../../../../services/alert';

import { ProgressIndicatorComponent } from '../../progress-indicator/progress-indicator.component';

@Component({
    selector: 'app-blog-detail',
    templateUrl: './blog.form.component.html',
    styleUrls: ['./blog.form.component.scss'],
})
export class BlogFormComponent implements OnInit {
    blog: Blog = new Blog();
    showProgressIndicator: boolean = false;
    errorMessage: String = null;

    constructor(
      private blogService: BlogService,
      private router: Router,
      private route: ActivatedRoute,
      private alertService: AlertService,
    ) { }

    ngOnInit () {
      this.route.params.subscribe(params => {
        const blogId = params['id'];

        // It means we're adding new blog
        if (!blogId) {
          return;
        }
        // We're editing existing, fetch from the server
        this.blogService.get(blogId).subscribe(blog => {
          this.blog = blog;
        });
      });
    }

    saveBlog () {
      this.showProgressIndicator = true;
      let request: Observable<any>;
      if (this.blog.id) { // Editing
        request = this.blogService.update(this.blog);
      } else { // Creating
        request = this.blogService.save(this.blog);
      }
      request.subscribe(data => this.router.navigate(['blogs']));

      request.subscribe(
        data => this.router.navigate(['blogs']),
        (err: any) => {
          console.log(err)
          if (err.error instanceof Error) {
            console.log('An error occurred:', err.error.message);
          } else {
            this.showProgressIndicator = false;
            const errorResponse = JSON.parse(err._body)
            this.errorMessage = errorResponse.message;
          }
        }
      );
    }

    deleteBlog (blogId: Number) {
      if (confirm('Are you sure you want to delete this blog?')) {
        this.blogService.delete(blogId).subscribe(resp => {
          // Delete will yield no content, check the status here
          if (resp.status === 204) {
            this.router.navigate(['blogs']);
          }
        });
      }
    }

    onUploadAvatar(event: any) {
      const secureUrl = get(event, 'secure_url');
      if (!secureUrl) {
        this.alertService
          .error('Oopps.. something went wrong uploading photo. Please try again.');
      }
      this.blog = {
        ...this.blog,
        avatar: secureUrl,
      };
    }

    onUploadPhoto(event: any) {
      const secureUrl = get(event, 'secure_url');
      if (!secureUrl) {
        this.alertService
          .error('Oopps.. something went wrong uploading photo. Please try again.');
      }
      this.blog = {
        ...this.blog,
        photo: secureUrl,
      };
    }

    // onDeletePhoto (index) {
    //   this.blog.photos.splice(index, 1);
    // }

}
