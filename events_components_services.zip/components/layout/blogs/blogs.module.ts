import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FileUploadModule } from 'ng2-file-upload';
import { PageHeaderModule } from '../page-header';
import { BlogsRoutingModule } from './blogs.routing.module';
import { BlogsComponent } from './blogs.component';
import { BlogFormComponent } from './blog-form/blog.form.component';
import { BlogService } from '../../../services/blog';
import { SharedModule } from '../shared/shared.module';
import { ProgressIndicatorModule } from '../progress-indicator/progress-indicator.module';

@NgModule({
  imports: [
    RouterModule,
    CommonModule,
    BlogsRoutingModule,
    PageHeaderModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    ProgressIndicatorModule,
  ],
  declarations: [
    BlogsComponent,
    BlogFormComponent,
  ],
  providers: [
    BlogService,
  ],
})
export class BlogsModule {}
