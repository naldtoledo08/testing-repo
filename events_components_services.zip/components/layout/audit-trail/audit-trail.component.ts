import { Component, OnInit } from '@angular/core';
import { NgIf } from '@angular/common';
import { AuditTrail } from '../../../models/auditTrail';
import { AuditTrailService } from '../../../services/auditTrail';
import { ProgressIndicatorComponent } from '../progress-indicator/progress-indicator.component';

@Component({
  selector: 'app-audit-trail',
  templateUrl: './audit-trail.component.html',
  styleUrls: ['./audit-trail.component.scss']
})
export class AuditTrailComponent implements OnInit {

  auditTrail: AuditTrail[] = [];
  totalCount: Number = 0;
  showProgressIndicator: boolean = false;
  sortField: String = 'dateCreated';
  sortOrder: String = 'desc';  

  constructor(private auditTrailService: AuditTrailService) { }

  ngOnInit() {
    this.loadMore()
  }

  loadMore() {
    this.showProgressIndicator = true;
    this.auditTrailService.list({
      sort : this.sortField,
      order : this.sortOrder,
      offset: this.auditTrail.length,
    }).subscribe(
      auditTrail => {
        this.showProgressIndicator = false;
        this.auditTrail = this.auditTrail.concat(auditTrail.data);
        this.totalCount = auditTrail.total;
      }
    );
  }

   sortTable(field){
      this.auditTrail = [];
      this.sortOrder = (this.sortOrder == "asc" && this.sortField == field) ? "desc" : "asc";      
      this.sortField = field;
      this.loadMore();
  }

}
