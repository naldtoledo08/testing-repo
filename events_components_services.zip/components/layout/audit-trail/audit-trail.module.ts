import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PageHeaderModule } from '../page-header';
import { AuditTrailRoutingModule } from './audit-trail.routing.module';

import { SharedModule } from '../shared/shared.module';

import { AuditTrailComponent } from './audit-trail.component';

import { AuditTrailService } from '../../../services/auditTrail';
import { ProgressIndicatorModule } from '../progress-indicator/progress-indicator.module';

@NgModule({
  imports: [
    RouterModule,
    CommonModule,
    AuditTrailRoutingModule,
    PageHeaderModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    ProgressIndicatorModule
  ],
  declarations: [
    AuditTrailComponent,
  ],
  providers: [
    AuditTrailService,
  ],
})
export class AuditTrailModule { }
