import { ActivitiesComponent } from './activities.component';
import { ActivityFormComponent } from './activity-form/activity-form.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
    { path: '', component: ActivitiesComponent, pathMatch: 'full' },
    { path: 'new', component: ActivityFormComponent },
    { path: ':id', component: ActivityFormComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ActivitiesRoutingModule { }
