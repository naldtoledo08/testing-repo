import { Content } from '../../../models/content';
import { ActivityService } from '../../../services/activity';
import { AuthService } from '../../../services/auth';
import { Component, OnInit } from '@angular/core';
import { NgIf, NgClass } from '@angular/common';
import { Observable } from 'rxjs';
import { AlertService } from '../../../services/alert';

@Component({
  selector: 'app-activities',
  templateUrl: './activities.component.html',
  styleUrls: ['./activities.component.scss'],
})
export class ActivitiesComponent implements OnInit {
  contents: Content[] = [];
  isMerchantUser: false;
  totalCount: Number = 0;
  sortField: String = 'title';
  sortOrder: String = 'asc';
  showProgressIndicator: boolean = false;
  batchContents: Content[] =[];
  content: Content = new Content();
  batchTogglerClass:string = 'hide';
  isBliimoAdmin: Boolean = false;
  //listBatchList:any = [];
  selectedCount:number;
  listToggler:string = 'hide';
  constructor(private activityService: ActivityService,
              private alertService: AlertService,
              private authService: AuthService ) { }

  ngOnInit() {
    this.isBliimoAdmin = this.authService.isBliimoAdmin();
    this.loadMore();
    this.isMerchantUser = this.authService.isMerchantUser();
  }

  loadMore() {
    this.alertService.clearMessage();
    this.showProgressIndicator = true;
    this.activityService.list(
      {
        sort : this.sortField,
        order: this.sortOrder,
        offset: this.contents.length
      }
    ).subscribe(
      contents => {
        this.showProgressIndicator = false;
        this.contents = this.contents.concat(contents.data);
        this.totalCount = contents.total;
      }
    );
  }

  sortTable(field){
      this.alertService.clearMessage();
      this.batchContents = [];
      this.contents = [];
      this.sortOrder = (this.sortOrder == "asc" && this.sortField == field) ? "desc" : "asc";      
      this.sortField = field;
      this.loadMore();
  }

  clickActivities(index, content){
    if(this.isBliimoAdmin){
      this.alertService.clearMessage();
      if(typeof this.batchContents[index] !== 'undefined'){
        //not recommended but needed to use to retain indexing, splice won't
        delete this.batchContents[index];
      }else{
        this.batchContents[index]=content;
      }

      this.batchTogglerClass = 'hide';
      //Workaround for deleting item in array since delete retain the count
      let countItems = 0;
      this.batchContents.forEach(element => {
         if(element) {
          //this.listBatchList = element
          this.batchTogglerClass = 'show';
          countItems++;
         }
      });
      if(countItems === 0) {
        this.listToggler = 'hide';
      }
      this.selectedCount = countItems;
    }
  }

  batchChangeSubStatus(status){
    var count = 0;
    var length = this.selectedCount;
    
    for (var i in this.batchContents) {
      count++;
      this.content = this.batchContents[i];
      this.content['subStatus'] = status;
      this.showProgressIndicator = true;

      let request: Observable<any>;
      request = this.activityService.updateActivityOnly(this.content);
      request.subscribe(
        data => {
          delete this.batchContents[i];
          if(count >= this.selectedCount){
            this.batchContents = [];
            this.selectedCount = 0;
            this.batchTogglerClass = 'hide';
            this.closeToggledList();
            this.showProgressIndicator = false;
            var type = (count > 1) ? "Activities" : "Activity";  
            this.alertService.success(length+" " + type +" Successfully "+ status);
          }
        },
        err => {
            this.showProgressIndicator = false;
            this.alertService.error("Error occur while updating your data.");
            },
        );
    }
  }

  toggleShowMiniList() {
    this.listToggler = (this.listToggler === 'hide' ? 'show' : 'hide' );
  }
  closeToggledList() {
    this.listToggler = 'hide';
  }

}
