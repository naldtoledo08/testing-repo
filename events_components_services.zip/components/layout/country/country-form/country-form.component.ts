import { Component, OnInit, Output, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HttpErrorResponse} from '@angular/common/http';
import get from 'lodash.get';

import { Country } from 'app/models/country';
import { CountryService } from 'app/services/country';

import { AlertService } from '../../../../services/alert';
import { ProgressIndicatorComponent } from '../../progress-indicator/progress-indicator.component';

@Component({
  selector: 'app-country-form',
  templateUrl: './country-form.component.html',
  styleUrls: ['./country-form.component.scss']
})
export class CountryFormComponent implements OnInit {

  @ViewChild('formCountry') formCountry:ElementRef;

  country: Country = new Country();
  errorMessage: String = null;
  showProgressIndicator: boolean = false;

  @Output() photoState;
  isPhotoValid:boolean = true;
  isSubmitted:boolean = false;

  constructor(
    private countryService: CountryService,
    
    private router: Router,
    private route: ActivatedRoute,
    private alertService: AlertService,
  ) { }

  ngOnInit() {
    // Retrieve partner detail if any
    this.route.params.subscribe(params => {
      const countryId = params['id'];

      // // It means we're adding new partner
      if (!countryId) {
        return;
      }else{       
        this.isSubmitted = true;
      }
      // // We're editing existing, fetch from the server
      this.countryService.get(countryId).subscribe(

        country => { this.country = country; },
        (err: any) => { this.router.navigate(['country']); }
      );
    });
  }

  onKeyupValidate() {
    var form:any = this.country;
    this.fonOnKeyupValidate(form.countryName,'countryName');
  }

  fonOnKeyupValidate(data,elementId) {
    if(!data || data == "") {
      this.formCountry.nativeElement.querySelector(`#${elementId}`).classList.add('input-error');
    }else {
      this.formCountry.nativeElement.querySelector(`#${elementId}`).classList.remove('input-error');
      return false;  
    }
    return true;
  }

  saveCountry () {
    this.isSubmitted = true;
    this.fonOnKeyupValidate(this.country.countryName, 'countryName');
    if(!this.country.countryName || this.country.countryName == "" || !this.country.imageUrl || this.country.imageUrl == "") {
       this.alertService.error("Please check all required fields.");
       if(this.country.imageUrl) {
        this.isPhotoValid = true;
      }else {
        this.isPhotoValid = false;
      }
       return false;
    }

    this.showProgressIndicator = true;
    let request: Observable<any>;
    if (this.country.id) { // Editing
      request = this.countryService.update(this.country);
    } else { // Creating
      request = this.countryService.save(this.country);
    }
    request.subscribe(
      data => this.router.navigate(['country']),
      (err: any) => {
        console.log(err)
        if (err.error instanceof Error) {
          // A client-side or network error occurred. Handle it accordingly.
          console.log('An error occurred:', err.error.message);
        } else {
          this.showProgressIndicator = false;
          const errorResponse = JSON.parse(err._body)
          this.errorMessage = errorResponse.message;
          // console.log(err)
          // The backend returned an unsuccessful response code.
          // The response body may contain clues as to what went wrong,
          // console.log(`Backend returned code ${err.status}, body was: ${err.error}`);
        }
      }
    );
  }


  onUploadPhoto(event: any) {
    const secureUrl = get(event, 'secure_url');
    if (!secureUrl) {
      this.alertService
        .error('Oopps.. something went wrong uploading photo. Please try again.');
    }
    this.country = {
      ...this.country,
      ['imageUrl']: secureUrl,
    };
    
  }

}
