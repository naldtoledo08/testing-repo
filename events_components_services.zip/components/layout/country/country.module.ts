import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PageHeaderModule } from '../page-header';
import { CountryRoutingModule } from './country.routing.module';

import { SharedModule } from '../shared/shared.module';

import { CountryComponent } from './country.component';

import { CountryService } from '../../../services/country';

import { ContractService } from '../../../services/contract';

import { CountryFormComponent } from './country-form/country-form.component';

import { ProgressIndicatorModule } from '../progress-indicator/progress-indicator.module';

@NgModule({
  imports: [
    RouterModule,
    CommonModule,
    CountryRoutingModule,
    PageHeaderModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    ProgressIndicatorModule,
  ],
  declarations: [
    CountryComponent,
    CountryFormComponent,
  ],
  providers: [
    CountryService,
    ContractService,
  ],
})
export class CountryModule { }
