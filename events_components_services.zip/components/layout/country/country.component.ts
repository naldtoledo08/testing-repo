import { Component, OnInit } from '@angular/core';

import { Country } from 'app/models/country';
import { CountryService } from 'app/services/country';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.scss']
})
export class CountryComponent implements OnInit {

  countries: Country[] = [];
  totalCount: Number = 0;
  showProgressIndicator: boolean = false;
  sortField: String = 'countryName';
  sortOrder: String = 'asc';

  constructor(private countryService: CountryService) { }

  ngOnInit() {
     this.loadMore();
  }

  loadMore() {    
    this.showProgressIndicator = true;
    this.countryService.list(
      {
        sort : this.sortField,
        order : this.sortOrder,
        offset: this.countries.length
      }
    ).subscribe(
      country => {

        this.showProgressIndicator = false;
        this.countries = this.countries.concat(country.data);
        this.totalCount = country.total;
      }
    );
  }

  sortTable(field){
      this.countries = [];
      this.sortOrder = (this.sortOrder == "asc" && this.sortField == field) ? "desc" : "asc";      
      this.sortField = field;
      this.loadMore();
  }

}