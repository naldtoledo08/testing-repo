import { Component, OnInit, Output, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HttpErrorResponse} from '@angular/common/http';
import get from 'lodash.get';

import { Category } from '../../../../models/category';
import { CategoryService } from '../../../../services/category/category.service';

import { Subcategory } from 'app/models/subcategory';
import { SubcategoryService } from 'app/services/subcategory';

import { AlertService } from '../../../../services/alert';
import { ProgressIndicatorComponent } from '../../progress-indicator/progress-indicator.component';

@Component({
  selector: 'app-subcategory-form',
  templateUrl: './subcategory-form.component.html',
  styleUrls: ['./subcategory-form.component.scss']
})
export class SubcategoryFormComponent implements OnInit {

  @ViewChild('formSubcategory') formSubcategory:ElementRef;

  categories: Category[] = [];
  subcategory: Subcategory = new Subcategory();
  errorMessage: String = null;
  showProgressIndicator: boolean = false;

  @Output() photoState;
  isPhotoValid:boolean = true;
  isSubmitted:boolean = false;

  constructor(    
    private categoryService: CategoryService,
    private subcategoryService: SubcategoryService,
    
    private router: Router,
    private route: ActivatedRoute,
    private alertService: AlertService,
  ) { }

  ngOnInit() {
    // Retrieve partner detail if any
    this.route.params.subscribe(params => {
      const subcategoryId = params['id'];

      // // It means we're adding new partner
      if (!subcategoryId) {
        return;
      }else{       
        this.isSubmitted = true;
      }
      // // We're editing existing, fetch from the server
      this.subcategoryService.get(subcategoryId).subscribe(
        subcategory => { this.subcategory = subcategory; },
        (err: any) => { this.router.navigate(['subcategory']); }
      );
    });
  }

  ngAfterViewInit() {
    this.loadCategories();
  }

  loadCategories() {
     this.categoryService.listWithoutSubcategory().subscribe(categories => {
        this.categories = categories;
     });
  }

  validate() {
    var form:any = this.subcategory;
    this.fonOnKeyupValidate(form.name,'name');
    this.fonOnKeyupValidate(form.categoryId,'category');
  }

  fonOnKeyupValidate(data,elementId) {
    if(!data || data == "") {
      this.formSubcategory.nativeElement.querySelector(`#${elementId}`).classList.add('input-error');
    }else {
      this.formSubcategory.nativeElement.querySelector(`#${elementId}`).classList.remove('input-error');
      return false;  
    }
    return true;
  }

  saveSubcategory () {
    this.isSubmitted = true;
    this.validate();
    if(!this.subcategory.name || this.subcategory.name == "" || !this.subcategory.image || this.subcategory.image == "" || !this.subcategory.categoryId) {
       this.alertService.error("Please check all required fields.");
       if(this.subcategory.image) {
        this.isPhotoValid = true;
      }else {
        this.isPhotoValid = false;
      }
       return false;
    }
    
    this.showProgressIndicator = true;
    let request: Observable<any>;
    if (this.subcategory.id) { // Editing
      request = this.subcategoryService.update(this.subcategory);
    } else { // Creating
      request = this.subcategoryService.save(this.subcategory, this.subcategory.categoryId);
    }
    request.subscribe(
      data => this.router.navigate(['subcategory']),
      (err: any) => {
        console.log(err)
        if (err.error instanceof Error) {
          // A client-side or network error occurred. Handle it accordingly.
          console.log('An error occurred:', err.error.message);
        } else {
          this.showProgressIndicator = false;
          const errorResponse = JSON.parse(err._body)
          this.errorMessage = errorResponse.message;
          // console.log(err)
          // The backend returned an unsuccessful response code.
          // The response body may contain clues as to what went wrong,
          // console.log(`Backend returned code ${err.status}, body was: ${err.error}`);
        }
      }
    );
  }


  onUploadPhoto(event: any) {

    const secureUrl = get(event, 'secure_url');
    if (!secureUrl) {
      this.alertService
        .error('Oopps.. something went wrong uploading photo. Please try again.');
    }
    this.subcategory = {
      ...this.subcategory,
      ['image']: secureUrl,
    };
    
  }

}
