import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PageHeaderModule } from '../page-header';
import { SubcategoryRoutingModule } from './subcategory.routing.module';

import { SharedModule } from '../shared/shared.module';

import { SubcategoryComponent } from './subcategory.component';

import { SubcategoryService } from '../../../services/subcategory';
import { CategoryService } from '../../../services/category/category.service';

import { ContractService } from '../../../services/contract';

import { SubcategoryFormComponent } from './subcategory-form/subcategory-form.component';

import { ProgressIndicatorModule } from '../progress-indicator/progress-indicator.module';

@NgModule({
  imports: [
    RouterModule,
    CommonModule,
    SubcategoryRoutingModule,
    PageHeaderModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    ProgressIndicatorModule,
  ],
  declarations: [
    SubcategoryComponent,
    SubcategoryFormComponent,
  ],
  providers: [
    SubcategoryService,
    ContractService,
    CategoryService,
  ],
})
export class SubcategoryModule { }
