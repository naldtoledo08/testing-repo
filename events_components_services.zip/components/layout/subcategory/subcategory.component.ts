import { Component, OnInit } from '@angular/core';

import { Subcategory } from 'app/models/subcategory';
import { SubcategoryService } from 'app/services/subcategory';
import { Category } from 'app/models/category';
import { CategoryService } from '../../../services/category/category.service';

@Component({
  selector: 'app-subcategory',
  templateUrl: './subcategory.component.html',
  styleUrls: ['./subcategory.component.scss']
})
export class SubcategoryComponent implements OnInit {

  subcategories: Subcategory[] = [];
  categories: Category[] = [];
  totalCount: Number = 0;
  showProgressIndicator: boolean = false;
  sortField: String = 'name';
  sortOrder: String = 'asc';

  constructor(private subcategoryService: SubcategoryService, private categoryService: CategoryService) { }

  ngOnInit() {    
    this.loadCategories();
    
  }

  ngAfterViewInit(){
    
  }

  loadCategories() {
    this.categoryService.listWithoutSubcategory().subscribe(categories => {
      this.categories = categories;
      this.loadMore();
    });
  }

  loadMore() {
    this.showProgressIndicator = true;
    this.subcategoryService.list(
      {
        sort : this.sortField,
        order : this.sortOrder,
        offset: this.subcategories.length
      }
    ).subscribe(
      subcategory => {
        this.showProgressIndicator = false;
        this.subcategories = this.subcategories.concat(subcategory.data);
        this.totalCount = subcategory.total;
      }
    );
  }

  sortTable(field){
      this.subcategories = [];
      this.sortOrder = (this.sortOrder == "asc" && this.sortField == field) ? "desc" : "asc";      
      this.sortField = field;
      this.loadMore();
  }

  getCategory(id){
    return this.categories[id-1].name;
  }

}