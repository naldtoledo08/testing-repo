import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-progress-indicator',
  template: '<div [hidden]="!showSpinner" class="loader"></div>',
  styleUrls: ['./progress-indicator.component.scss'],
})
export class ProgressIndicatorComponent {
  private _showSpinner: boolean = false;
  
  constructor() {}
  
  @Input()
  set showSpinner(value: boolean) {
    this._showSpinner = value;
  }
  
  get showSpinner() {
    return this._showSpinner;
  }
}
