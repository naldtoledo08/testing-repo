import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardRouting } from './dashboard.routing.module';

import { DashboardComponent } from 'app/components/layout/dashboard/dashbolard.compoent';


@NgModule({
    imports:[
        CommonModule,
        DashboardRouting
    ],
    declarations: [
        DashboardComponent
    ]
})

export class DashboardModule {}