import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PageHeaderModule } from '../page-header';
import { ProfileRoutingModule } from './profile.routing.module';

import { SharedModule } from '../shared/shared.module';

import { ProfileComponent } from './profile.component';

import { ProfileService } from '../../../services/profile';

@NgModule({
  imports: [
    RouterModule,
    CommonModule,
    ProfileRoutingModule,
    PageHeaderModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
  ],
  declarations: [
    ProfileComponent,
  ],
  providers: [
    ProfileService,
  ],
})
export class ProfileModule { }
