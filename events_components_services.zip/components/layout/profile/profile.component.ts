import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HttpErrorResponse} from '@angular/common/http';
import get from 'lodash.get';

import { Me } from 'app/models/me';
import { Merchant } from 'app/models/merchant';

import { AuthService } from 'app/services/auth';
import { ProfileService } from 'app/services/profile';
import { AlertService } from 'app/services/alert';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {

  me: Me;
  errorMessage: String = null;
  merchant: Merchant = new Merchant();

  constructor(
    private profileService: ProfileService,
    private authService: AuthService,
    private alertService: AlertService,
    private router: Router,
  ) { }

  ngOnInit() {
    // Retrieve profile details
    this.me = this.authService.getUser();
    console.log('me', this.me)

    this.profileService.get(this.me.id).subscribe(
      merchant => { this.merchant = merchant; },
      (err: any) => {
        console.log('Error', err)
       }
    );

  }

  updateProfile() {
    let request: Observable<any>;
    request = this.profileService.update(this.merchant);
    request.subscribe(
      data => {
        this.alertService.success('Success!', true)
        this.router.navigate(['/profile'])
      },
      (err: any) => {
        console.log(err)
        if (err.error instanceof Error) {
          // A client-side or network error occurred. Handle it accordingly.
          console.log('An error occurred:', err.error.message);
        } else {
          const errorResponse = JSON.parse(err._body)
          this.errorMessage = errorResponse.message
          console.log(err)
          // The backend returned an unsuccessful response code.
          // The response body may contain clues as to what went wrong,
          console.log(`Backend returned code ${err.status}, body was: ${err.error}`);
        }
      }
    );
  }

}
