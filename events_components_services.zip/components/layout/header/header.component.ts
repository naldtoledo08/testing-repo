import { Component, OnInit } from '@angular/core';

import { Me } from '../../../models/me';
import { AuthService } from '../../../services/auth';
import { PartnerService } from '../../../services/partner';
@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {

  me: Me;
  isBliimoUser: boolean = false;
  isBliimoAdmin: boolean = false;

  constructor(private authService: AuthService, private partnerService: PartnerService) { }

  ngOnInit() {
    var user = this.authService.getUser();
    this.me = this.authService.getUser();
    this.isBliimoUser = this.authService.isBliimoUser();
    if(user.partnerId){
      this.partnerService.get(user.partnerId).subscribe(
          partner => { 
            console.log(partner);
            user.fullName = user.fullName + ' - ' + partner.name;
            this.me  = user;
          },
        );
    }
  }

  toggleSidebar() {
      const dom: any = document.querySelector('body');
      dom.classList.toggle('push-right');
  }

  onLoggedout() {
    sessionStorage.removeItem('user');
    sessionStorage.removeItem('token');
  }
}
