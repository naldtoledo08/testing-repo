import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import { AuthService } from '../../services/auth';
import { AlertService } from '../../services/alert';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  model: any = {};
  hasError = false;
  returnUrl: string;

  constructor(
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router,
    private alertService: AlertService
  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe((params: Params) => {
        if (params.at && params.rt && params.r) {
          this.authService.me(params.at, params.rt, params.r)
            .subscribe(
              data => {
                this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/dashboard';
                this.router.navigate([this.returnUrl]);
              },
              error => {
                this.alertService.error('We have found issue authenticating.');
              },
            );
        }
      });
  }

  login() {
    this.authService.login(this.model.username, this.model.password)
      .subscribe(
        data => {
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/dashboard';
          this.router.navigate([this.returnUrl]);
        },
        error => {
          this.alertService.error('Incorrect username or password');
        },
      );
  }
}
