import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import { AppConfig } from '../../app.config';

@Injectable()
export class AuthService {
  constructor(private http: Http, private config: AppConfig) { }

  login(username: string, password: string) {
    return this.http.post(this.config.API + '/api/login', {
        username: username,
        password: password,
      })
      .map((response: Response) => {
        const json = response.json();
        if (json.success) {
          const { profile: user, ...rest } = json.data;
          this.setToken(rest, user);
        }
      });
  }

  me(accessToken: string, refreshToken: string, roles: string) {
    this.setToken({
      access_token: accessToken,
      refresh_token: refreshToken,
      roles: roles.split(','),
    });

    return this.http.get(`${this.config.API}/api/me`, this.getAuthorization())
      .map((response: Response) => {
        const user = response.json();
        this.setToken(null, user);
      });
  }

  setToken(token: any = null, user: any = null) {
    if (token) sessionStorage.setItem('token', JSON.stringify(token));
    if(user) sessionStorage.setItem('user', JSON.stringify(user));
  }

  logout() {
      // remove user from local storage to log user out
      sessionStorage.removeItem('token');
      sessionStorage.removeItem('user');
  }

  getUser() {
    return JSON.parse(sessionStorage.getItem('user'));
  }

  getToken() {
    return JSON.parse(sessionStorage.getItem('token'));
  }

  isBliimoAdmin() {
    return this.getToken().roles.some(role => role === 'ROLE_BACKOFFICE_ADMIN');
  }

  isBliimoUser() {
    return this.getToken().roles.some(role => role === 'ROLE_BACKOFFICE_ADMIN' || role === 'ROLE_BACKOFFICE_USER');
  }

  isMerchantAdmin() {
    return this.getToken().roles.some(role => role === 'ROLE_MERCHANT_ADMIN');
  }

  isMerchantUser() {
    return this.getToken().roles.some(role => role === 'ROLE_MERCHANT_ADMIN' || role === 'ROLE_MERCHANT_USER');
  }

  getAuthorization() {
    const authToken = this.getToken();
    const headers = new Headers({ Authorization: `Bearer ${authToken.access_token}` });
    return new RequestOptions({ headers });
  }
}
