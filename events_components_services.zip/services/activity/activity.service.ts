import { Injectable } from "@angular/core";
import { Http, Headers, Response, RequestOptions } from "@angular/http";
import { AppConfig } from "../../app.config";
import { AuthService } from "../../services/auth";
import { Content } from "../../models/content";
import { Series } from "../../models/series";
import { Observable } from "rxjs";

@Injectable()
export class ActivityService {
  authorization: RequestOptions;

  constructor(
    private http: Http,
    private config: AppConfig,
    private authService: AuthService
  ) {
    this.authorization = authService.getAuthorization();
  }

  list(params = {}) {
    this.authorization = this.authService.getAuthorization();
    return this.http
      .get(`${this.config.API}/api/adventures`, {
        ...this.authorization,
        search: params
      })
      .map((response: Response) => {
        return response.json();
      });
  }

  get(id: Number) {
    return this.http
      .get(`${this.config.API}/api/adventures/${id}`, this.authorization)
      .map((response: Response) => {
        return response.json();
      });
  }

  getaddons(id: Number) {
    return this.http
      .get(`${this.config.API}/api/adventures/${id}/addons`, this.authorization)
      .map((response: Response) => {
        return response.json();
      });
  }

  getseries(id: Number) {
    return this.http
      .get(`${this.config.API}/api/adventures/${id}/series`, this.authorization)
      .map((response: Response) => {
        return response.json();
      });
  }

  save(activityParam: Content) {
    return this.http
      .post(
        `${this.config.API}/api/adventures`,
        activityParam,
        this.authorization
      )
      .map((response: Response) => {
        return response.json();
      })
      .flatMap((savedActivity: any) => {
        if (savedActivity && savedActivity.id && activityParam.seriesArr) {
          if (activityParam.seriesArr.length > 0) {
            return Observable.forkJoin(
              activityParam.seriesArr.map((series: any) => {
                return this.http
                  .post(
                    `${this.config.API}/api/adventures/` +
                      savedActivity.id +
                      "/series",
                    series,
                    this.authorization
                  )
                  .map((res: any) => {
                    const savedSeries: Series = res["_body"];
                    if (!savedActivity.seriesArr) {
                      savedActivity.seriesArr = [];
                    }
                    savedActivity.seriesArr.push(savedSeries);
                  });
              })
            );
          }
        } else {
          console.log("watapen!");
        }
        return Observable.of(savedActivity);
      });
  }

  update(content: Content) {
    return this.http
      .put(
        `${this.config.API}/api/adventures/${content.id}`,
        content,
        this.authorization
      )
      .map((response: Response) => {
        return response.json();
      })
      .flatMap((savedActivity: any) => {
        if (savedActivity && savedActivity.id && content.seriesArr) {
          if (content.seriesArr.length > 0) {
            return Observable.forkJoin(
              content.seriesArr.map((series: any) => {
                return this.http
                  .post(
                    `${this.config.API}/api/adventures/` +
                      savedActivity.id +
                      "/series",
                    series,
                    this.authorization
                  )
                  .map((res: any) => {
                    const savedSeries: Series = res["_body"];
                    if (!savedActivity.seriesArr) {
                      savedActivity.seriesArr = [];
                    }
                    savedActivity.seriesArr.push(savedSeries);
                  });
              })
            );
          }
        }
        return Observable.of(savedActivity);
      });
  }

  updateActivityOnly(content: Content) {
    return this.http
      .put(
        `${this.config.API}/api/adventuresbatch/${content.id}`,
        content,
        this.authorization
      )
      .map((response: Response) => {
        return response.json();
      });
  }

  delete(id: Number) {
    return this.http
      .delete(`${this.config.API}/api/adventures/${id}`, this.authorization)
      .map((response: Response) => {
        return response;
      });
  }

  observableSource = (keyword: any): Observable<any[]> => {
    // let url: string = 'https://maps.googleapis.com/maps/api/geocode/json?address='+keyword
    let url: string = `${this.config.API}/api/localities`;
    let params = {
      sort: "name",
      order: "asc",
      keyword: keyword
    };
    if (keyword) {
      return this.http
        .get(url, { ...this.authorization, search: params })
        .map(res => {
          let json = res.json();
          return json.data;
        });
    } else {
      return Observable.of([]);
    }
  };
}
