import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import { AppConfig } from '../../app.config';
import { AuthService } from '../../services/auth';

import { Subcategory } from 'app/models/subcategory';

@Injectable()
export class SubcategoryService {
  authorization: RequestOptions;
  constructor(private http: Http, private config: AppConfig, private authService: AuthService) {
    this.authorization = authService.getAuthorization();
  }

  list(params = {}) {
    return this.http.get(`${this.config.API}/api/subcategories`, { ...this.authorization, search: params })
      .map((response: Response) => {
        return response.json();
      });
  }

  get(id: Number) {
    return this.http.get(`${this.config.API}/api/subcategories/${id}`, this.authorization)
      .map((response: Response) => {
        return response.json();
      });
  }

  save(subcategory: Subcategory, categoryId: Number) {

    return this.http.post(`${this.config.API}/api/categories/${categoryId}/subcategories`, subcategory, this.authorization)
      .map((response: Response) => {
        return response.json();
      });
  }

  update(subcategory: Subcategory) {
    return this.http.put(`${this.config.API}/api/subcategories/${subcategory.id}`, subcategory, this.authorization)
      .map((response: Response) => {
        return response.json();
      });
  }

  delete(id: Number) {
    return this.http.delete(`${this.config.API}/api/subcategories/${id}`, this.authorization)
      .map((response: Response) => {
        return response;
      });
  }

}
