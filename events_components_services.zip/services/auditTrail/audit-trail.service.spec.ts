import { TestBed, inject } from '@angular/core/testing';

import { AuditTrailService } from './audit-trail.service';

describe('AuditTrailService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuditTrailService]
    });
  });

  it('should be created', inject([AuditTrailService], (service: AuditTrailService) => {
    expect(service).toBeTruthy();
  }));
});
