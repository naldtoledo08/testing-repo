import { AppConfig } from '../../app.config';
import { Category } from '../../models/category';
import { Subcategory } from '../../models/subcategory';
import { AuthService } from '../auth';
import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';

@Injectable()
export class CategoryService {

  authorization: RequestOptions;
  
  constructor(private http: Http, private config: AppConfig, private authService: AuthService) {
    this.authorization = authService.getAuthorization();
  }
  
  list(params = {}): Observable<Category[]> {
    return this.http.get(`${this.config.API}/api/categories`, { ...this.authorization, search: params })
      .map((res: Response) => {
        return res.json()['data'];
      })
      .flatMap((categories: Category[]) => {
        if (categories.length > 0) {
          return Observable.forkJoin(
            categories.map((category: any) => {
              return this.http.get(`${this.config.API}/api/categories/` + category.id + '/subcategories',
                { ...this.authorization, search: params })
                .map((res: any) => {
                  const subcategories: Subcategory = res.json()['data'];
                  category.subcategories = subcategories;
                  return category;
                });
            }),
          );
        }
        return Observable.of([]);
      });
  }

  listWithoutSubcategory(params = {}): Observable<Category[]> {
    return this.http.get(`${this.config.API}/api/categories`, { ...this.authorization, search: params })
      .map((response: Response) => {
        return response.json()['data'];
      });
  }

}
