import { Injectable } from "@angular/core";
import { Http, Headers, Response, RequestOptions } from "@angular/http";
import { AppConfig } from "../../app.config";
import { AuthService } from "../../services/auth";
import { Content } from "../../models/content";
import { Series } from "../../models/series";
import { Observable } from "rxjs";

@Injectable()
export class EventService {
  authorization: RequestOptions;

  constructor(
    private http: Http,
    private config: AppConfig,
    private authService: AuthService
  ) {
    this.authorization = authService.getAuthorization();
  }

  list(params = {}) {
    this.authorization = this.authService.getAuthorization();
    return this.http
      .get(`${this.config.API}/api/events`, {
        ...this.authorization,
        search: params
      })
      .map((response: Response) => {
        return response.json();
      });
  }

  get(id: Number) {
    return this.http
      .get(`${this.config.API}/api/events/${id}`, this.authorization)
      .map((response: Response) => {
        return response.json();
      });
  }

  getaddons(id: Number) {
    return this.http
      .get(`${this.config.API}/api/events/${id}/addons`, this.authorization)
      .map((response: Response) => {
        return response.json();
      });
  }

  getseries(id: Number) {
    return this.http
      .get(`${this.config.API}/api/events/${id}/series`, this.authorization)
      .map((response: Response) => {
        return response.json();
      });
  }

  save(eventParam: Content) {
    return this.http
      .post(`${this.config.API}/api/events`, eventParam, this.authorization)
      .map((response: Response) => {
        return response.json();
      })
      .flatMap((savedEvent: any) => {
        if (savedEvent && savedEvent.id && eventParam.seriesArr) {
          if (eventParam.seriesArr.length > 0) {
            return Observable.forkJoin(
              eventParam.seriesArr.map((series: any) => {
                return this.http
                  .post(
                    `${this.config.API}/api/events/` +
                      savedEvent.id +
                      "/series",
                    series,
                    this.authorization
                  )
                  .map((res: any) => {
                    const savedSeries: Series = res["_body"];
                    if (!savedEvent.seriesArr) {
                      savedEvent.seriesArr = [];
                    }
                    savedEvent.seriesArr.push(savedSeries);
                  });
              })
            );
          }
        } else {
          console.log("watapen!");
        }
        return Observable.of(savedEvent);
      });
  }

  update(content: Content) {
    return this.http
      .put(
        `${this.config.API}/api/events/${content.id}`,
        content,
        this.authorization
      )
      .map((response: Response) => {
        return response.json();
      })
      .flatMap((savedEvent: any) => {
        if (savedEvent && savedEvent.id && content.seriesArr) {
          if (content.seriesArr.length > 0) {
            return Observable.forkJoin(
              content.seriesArr.map((series: any) => {
                return this.http
                  .post(
                    `${this.config.API}/api/events/` +
                      savedEvent.id +
                      "/series",
                    series,
                    this.authorization
                  )
                  .map((res: any) => {
                    const savedSeries: Series = res["_body"];
                    if (!savedEvent.seriesArr) {
                      savedEvent.seriesArr = [];
                    }
                    savedEvent.seriesArr.push(savedSeries);
                  });
              })
            );
          }
        }
        return Observable.of(savedEvent);
      });
  }

  updateEventOnly(content: Content) {
    return this.http
      .put(
        `${this.config.API}/api/eventsbatch/${content.id}`,
        content,
        this.authorization
      )
      .map((response: Response) => {
        return response.json();
      });
  }

  delete(id: Number) {
    return this.http
      .delete(`${this.config.API}/api/events/${id}`, this.authorization)
      .map((response: Response) => {
        return response;
      });
  }

  observableSource = (keyword: any): Observable<any[]> => {
    // let url: string = 'https://maps.googleapis.com/maps/api/geocode/json?address='+keyword
    let url: string = `${this.config.API}/api/localities`;
    let params = {
      sort: "name",
      order: "asc",
      keyword: keyword
    };
    if (keyword) {
      return this.http
        .get(url, { ...this.authorization, search: params })
        .map(res => {
          let json = res.json();
          return json.data;
        });
    } else {
      return Observable.of([]);
    }
  };
}
