import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import { AppConfig } from '../../app.config';
import { AuthService } from '../../services/auth';

import { Partner } from '../../models/partner';

@Injectable()
export class PartnerService {
  authorization: RequestOptions;
  constructor(private http: Http, private config: AppConfig, private authService: AuthService) {
    this.authorization = authService.getAuthorization();
  }

  list(params = {}) {
    return this.http.get(`${this.config.API}/api/partners`, { ...this.authorization, search: params })
      .map((response: Response) => {
        return response.json();
      });
  }

  get(id: Number) {
    return this.http.get(`${this.config.API}/api/partners/${id}`, this.authorization)
      .map((response: Response) => {
        return response.json();
      });
  }

  save(partner: Partner) {
    return this.http.post(`${this.config.API}/api/partners`, partner, this.authorization)
      .map((response: Response) => {
        return response.json();
      });
  }

  update(partner: Partner) {
    return this.http.put(`${this.config.API}/api/partners/${partner.id}`, partner, this.authorization)
      .map((response: Response) => {
        return response.json();
      });
  }

  delete(id: Number) {
    return this.http.delete(`${this.config.API}/api/partners/${id}`, this.authorization)
      .map((response: Response) => {
        return response;
      });
  }

}
