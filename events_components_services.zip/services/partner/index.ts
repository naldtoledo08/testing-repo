export * from './partner.service';
