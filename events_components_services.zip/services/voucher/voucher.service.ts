import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { AppConfig } from '../../app.config';

import { AuthService } from 'app/services/auth';

@Injectable()
export class VoucherService {

  authorization: RequestOptions;

  constructor(private http: Http, private config: AppConfig, private authService: AuthService) {
    this.authorization = authService.getAuthorization();
  }

  list(params = {}) {
    return this.http.get(`${this.config.API}/api/vouchers`, { ...this.authorization, search: params })
      .map((response: Response) => {
        return response.json();
      });
  }

}
