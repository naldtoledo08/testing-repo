export * from './locality.service';
